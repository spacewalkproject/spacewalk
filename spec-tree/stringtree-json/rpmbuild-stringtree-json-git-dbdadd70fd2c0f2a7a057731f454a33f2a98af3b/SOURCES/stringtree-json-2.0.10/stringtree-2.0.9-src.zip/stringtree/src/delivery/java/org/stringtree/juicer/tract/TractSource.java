package org.stringtree.juicer.tract;

import org.stringtree.Tract;

public interface TractSource {
	Tract nextTract();
}
