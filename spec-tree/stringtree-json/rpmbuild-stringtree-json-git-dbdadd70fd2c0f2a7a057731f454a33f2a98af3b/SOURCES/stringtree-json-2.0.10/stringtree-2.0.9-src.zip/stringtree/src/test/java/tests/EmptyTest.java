package tests;

import junit.framework.TestCase;

public class EmptyTest extends TestCase {
    
    public void setUp() {
        // this method intentionally left blank!
    }

    public void testEmpty() {
        // this method intentionally left blank!
    }
}
