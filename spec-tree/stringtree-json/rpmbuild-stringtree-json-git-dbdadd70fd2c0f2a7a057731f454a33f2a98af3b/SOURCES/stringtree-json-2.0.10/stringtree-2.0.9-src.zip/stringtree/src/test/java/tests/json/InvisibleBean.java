package tests.json;

public class InvisibleBean {
    
    public boolean visible = false;
}
