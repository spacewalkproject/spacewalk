package org.stringtree.juicer.string;

public interface StringSource {
	String nextString();
}
