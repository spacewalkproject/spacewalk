package org.stringtree.fetcher;

public interface LiveObjectWrapper {
    Object getObject();
    Object getRaw();
}
