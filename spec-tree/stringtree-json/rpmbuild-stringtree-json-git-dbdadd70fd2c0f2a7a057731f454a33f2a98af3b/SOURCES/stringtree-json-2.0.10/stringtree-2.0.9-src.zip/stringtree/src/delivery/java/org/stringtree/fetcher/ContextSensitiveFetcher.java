package org.stringtree.fetcher;

import org.stringtree.Fetcher;

public interface ContextSensitiveFetcher {
    void setContext(Fetcher context);
}
