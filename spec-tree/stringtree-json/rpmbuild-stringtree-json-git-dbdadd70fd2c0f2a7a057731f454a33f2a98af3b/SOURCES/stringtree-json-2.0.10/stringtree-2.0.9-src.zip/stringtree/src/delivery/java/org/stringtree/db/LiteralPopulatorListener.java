package org.stringtree.db;

public interface LiteralPopulatorListener extends LiteralPopulator, RowListener {
}
