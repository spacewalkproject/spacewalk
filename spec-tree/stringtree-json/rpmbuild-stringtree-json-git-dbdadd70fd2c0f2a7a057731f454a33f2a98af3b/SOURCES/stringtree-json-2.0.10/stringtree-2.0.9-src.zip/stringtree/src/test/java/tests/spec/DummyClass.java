package tests.spec;

public class DummyClass {
    public int requests = 0;
}
