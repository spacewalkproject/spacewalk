package org.stringtree.finder;

import org.stringtree.Repository;
import org.stringtree.Storer;

public interface StringKeeper extends StringFinder, Storer, Repository {

    // this interface intentionally left blank
}
