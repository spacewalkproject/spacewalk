package tests.json;

public class InvisibleSizeBean {
    
    public boolean visible = false;

    public int getSize() {
        return 13;
    }
}
