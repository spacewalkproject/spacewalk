package org.stringtree.fetcher;

public interface RawFetcher {
    Object getRawObject(String name);
}
