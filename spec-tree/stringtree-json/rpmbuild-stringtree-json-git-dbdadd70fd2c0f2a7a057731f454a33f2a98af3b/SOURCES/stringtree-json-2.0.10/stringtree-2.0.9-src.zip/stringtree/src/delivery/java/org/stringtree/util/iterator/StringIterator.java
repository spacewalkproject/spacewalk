package org.stringtree.util.iterator;

import java.util.Iterator;

public interface StringIterator extends Iterator {
    String nextString();
}
