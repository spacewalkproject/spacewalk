package tests.json;

public class SizeBean {
    
    public int getSize() {
        return 13;
    }
}
