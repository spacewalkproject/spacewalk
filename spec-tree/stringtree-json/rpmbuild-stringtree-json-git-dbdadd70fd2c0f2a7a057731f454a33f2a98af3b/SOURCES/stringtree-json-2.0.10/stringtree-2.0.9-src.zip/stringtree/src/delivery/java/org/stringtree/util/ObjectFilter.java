package org.stringtree.util;

public interface ObjectFilter {
    boolean accept(Object obj);
}
