package org.stringtree.db;

public interface LiteralListener extends RowListener {
    String getSQL();
}
