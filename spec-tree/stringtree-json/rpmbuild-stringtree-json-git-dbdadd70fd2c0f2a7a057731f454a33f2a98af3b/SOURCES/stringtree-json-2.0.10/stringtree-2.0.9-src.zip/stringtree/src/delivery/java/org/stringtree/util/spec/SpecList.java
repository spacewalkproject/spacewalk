package org.stringtree.util.spec;

import java.util.ArrayList;

class SpecList extends ArrayList implements CreatedHere {
    // this class intentionally left blank
}
