package org.stringtree.juicer;

import org.stringtree.Fetcher;

public interface AugmentedTransformation {
	public void setAugment(Fetcher augment);
}
