package org.stringtree.db;

public interface LiteralPopulator extends StatementPopulator {
    String getSQL();
}
