package tests.fetcher;

public class SimpleBean {
    
    public String getAa() {
        return "hello from aa";
    }

    public String bb() {
        return "hello from bb";
    }

    public String cc = "hello from cc";
    
    public boolean isBoolD() {
        return true;
    }
    
    public boolean getBoolD() {
        return false;
    }
    
    public Boolean isBoolE() {
        return Boolean.TRUE;
    }
    
    public Boolean getBoolE() {
        return Boolean.FALSE;
    }
    
    public String stone = "direct";
    public String getStone() {
        return "method";
    }
    
    public boolean blood = true;
    public boolean isBlood() {
        return false;
    }
}
