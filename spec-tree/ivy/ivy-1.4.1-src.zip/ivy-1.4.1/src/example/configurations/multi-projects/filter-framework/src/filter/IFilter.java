package filter;

public interface IFilter {
    String[] filter(String[] values, String prefix);
}
