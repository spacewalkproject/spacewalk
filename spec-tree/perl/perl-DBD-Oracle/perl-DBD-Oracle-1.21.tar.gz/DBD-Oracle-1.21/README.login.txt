This information is now in the DBD::Oracle module pod documentation.
Use the 'perldoc DBD::Oracle' command to read it.

Note: The test scripts use the ORACLE_USERID environment variable
to determine who to login as. It's common to use the Oracle demo user
'scott' with the standard password 'tiger', thus ORACLE_USERID can be
set to 'scott/tiger', or set it to your own username and password.
