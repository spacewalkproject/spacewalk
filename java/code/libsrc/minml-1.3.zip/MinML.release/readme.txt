MinML is an XML parser written in Java. It was written to be used in embedded Java
systems where storage space is at a premium. The code is quite compact 
(~9Kb including a simple test program and all the necessary SAX classes).
However, MinML was also designed to minimise the heap space used by the program
when parsing a document. We believe that MinML is unique in this respect.

MinML does not implement all of the XML standard. The principle omission is:

DTDs - MinML reads and ignores DTDs

In addition MinML is very lax in checking that the spelling tags and attribute
names conforms to the letter of the standard.

MinML performance has been significantly improved in recent releases. It seems
to perform pretty well compared to large XML parsers and extramly well on small
XML files. See http://www.extreme.indiana.edu/~aslom/exxp/

MinML implements the SAX1 API.

We have extended the API to allow the calling program to supply an instance of a subclass
of java.io.Writer at the start of an element. The parser will then write all the character
data to the Writer instance rather than pass it back using the SAX characters call.
Look int the uk.xml.org.sax package for deatils.

The code has been tested on Dallas Semiconductor's TINI system
(http://www.ibutton.com/TINI/index.html) using the release 1.0c firmware and on
Windows NT using JDK 1.3.

We would be *very* grateful for any reports, good or bad, about the use of this
parser in real applications.

The source is released under a BSD style licence (see licence.txt).

The distribution also contains some files which are TINI specific:

MinMLTest.tini is a runnable version of the MinML test program.

mk.bat and MinML.cmd make MinMLTest.tini and ftps it to my test system. This
has lots of stuff which is specific to my system but it should be reasonably easy
to see what need changing.

On non TINI systems:

java -cp .;MinML.jar MinMLTest < manifest.xml

stands a reasonable chance of doing something mildly interesting.

Thanks

Thanks go to the software and hardware people at Dallas Semiconductor for
producing such an interesting device, and especially to Don Loomis for fixing
the stuff I broke!


Thanks also to Don Park who came up with the Minimal XML subset and set me thinking
about small parsers (Note: MinML now implements a substantial superset of Don's Minimal XML)

Thanks to Frederic Romeas for integrating MinML into Hannes Walln�fer's XML-RPC
implementation and finding a bug in JDK 1.2 which would have been a severe problem
if we had not found a workaround.

11th November 2001

John Wilson
The Wilson Partnership
5 Market Hill, Whitchurch, Aylesbury, Bucks HP22 4JB, UK
+44 1296 641072, +44 7976 611010(mobile), +44 1296 641874(fax)
email: tug@wilson.co.uk, URL: http://www.wilson.co.uk/


