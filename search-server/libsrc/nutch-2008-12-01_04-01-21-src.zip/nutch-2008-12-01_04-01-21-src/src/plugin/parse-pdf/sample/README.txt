20040710, John Xing

./pdftest.pdf: a small pdf file picked up from internet.

Used for junit test by ./src/test/org/apache/nutch/parse/pdf/TestPdfParser.java

It contains text:
E:\M55\!\1725.fm 2003-01-01 18:15 P Tagg, IPM, University of Liverpool
A VERY SMALL PDF FILE
A VERY SMALL PDF FILE
A VERY SMALL PDF FILE
A VERY SMALL PDF FILE
A VERY SMALL PDF FILE
A VERY SMALL PDF FILE
