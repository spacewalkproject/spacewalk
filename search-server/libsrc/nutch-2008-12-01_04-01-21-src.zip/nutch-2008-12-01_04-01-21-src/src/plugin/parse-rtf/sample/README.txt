
./test.rtf: A short rtf file created with OpenOffice.org contain the text unquoted

"The quick brown fox jumps over the lazy dog"

-- Andy Hedges