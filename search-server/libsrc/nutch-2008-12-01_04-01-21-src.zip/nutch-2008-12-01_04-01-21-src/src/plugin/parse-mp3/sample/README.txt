Andy Hedges

Orginal MP3 from postgreSQL.org

./postgresql-id3v1.mp3: A short MP3 file with ID3v1 tags added with kid3
./postgresql-id3v2.mp3: A short MP3 file with ID3v2 tags added with kid3
./postgresql-none.mp3:  A short MP3 file with no ID3 tags of any kind
./test.mp3:             A corrupt MP3 file that has been truncated half way through the ID3v2 frames
                        (not used in any test as yet).

Used for junit test by ./src/test/org/apache/nutch/parse/mp3/TestMP3Parser.java
