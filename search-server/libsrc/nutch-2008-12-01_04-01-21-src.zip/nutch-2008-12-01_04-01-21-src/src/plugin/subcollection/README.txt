For brief description about this plugin see
src/java/org/apache/nutch/collection/package.html

Basically:
You need to enable this during indexing and during searching

After indexing you can limit your searches to certain
subcollection with keyword subcollection, eg. 

"subcollection:nutch hadoop"
