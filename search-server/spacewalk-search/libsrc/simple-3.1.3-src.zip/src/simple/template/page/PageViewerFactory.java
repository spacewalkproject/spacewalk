/*
 * PageVeiwerFactory.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.page;

import simple.template.layout.ViewerFactory;
import java.io.FileNotFoundException;
import simple.template.layout.Viewer;
import simple.http.serve.Context;
import simple.page.Workspace;
import simple.page.Composer;
import simple.page.Model;
import simple.page.Page;

/**
 * The <code>PageVeiwerFactory</code> resolves a viewer
 * instance from a specified path. The location of the viewer
 * is relative to the user specified <cite>Page</cite> 
 * template root. The viewers resolved by this factory object
 * wrap the template located at the specified path. In order 
 * to supply an initial set of data to a created viewer object 
 * a <code>Model</code> instance must be supplied.
 *
 * @author Niall Gallagher 
 */
final class PageViewerFactory implements ViewerFactory {
   
   /**
    * Used to translate and compile the JSP template pages.
    */         
   private Composer composer;
        
   /**
    * Constructor for the <code>PageVeiwerFactory</code>. This
    * creates a factory for creating viewer objects. The engine is
    * used to create and configure all referenced templates which
    * are then wrapped in a <code>Viewer</code> object.
    *
    * @param project the project used to acquire the templates 
    * @param context the context used to resolve MIME types
    */
   public PageViewerFactory(Workspace project, Context context) throws Exception {
      this.composer = new Composer(context, project);           
   }

   /**      
    * Retrieves the referenced <code>Page</code> object from the
    * JSP templating system. This method is provided for convenience,
    * to avoid using <code>compose</code> method exposed by the
    * <code>Composer</code> object. By default this uses UTF-8.
    *
    * @param path this is the path used to locate the template
    */
   private Page getPage(String path) throws Exception {
      return composer.compose(path);
   }
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the <cite>Page</cite> runtime, which
    * acquires all resources from a user specified template root.
    * <p>
    * The viewer created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created viewer object affect only that 
    * instance. By default this assumes the UTF-8 encoding. 
    * <p>
    * To provide an initial set of properties to the viewer an
    * <code>Object</code> is used to populate the viewer. All
    * that is required to supply supplemental properties to the
    * viewer is to provide a populated <code>Model</code>.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared   
    */
   public Viewer getInstance(String path, Object data, boolean share) throws Exception {
      return getInstance(path, (Model)data, share);
   }
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the <cite>Page</cite> runtime, which
    * acquires all resources from a user specified template root.
    * <p>
    * The viewer created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created viewer object affect only that 
    * instance. By default this assumes the UTF-8 encoding. 
    * <p>
    * To provide an initial set of properties to the viewer a
    * <code>Model</code> is used to populate the viewer. All
    * that is required to supply supplemental properties to the
    * viewer is to provide a populated <code>Model</code>.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared    
    */
   private Viewer getInstance(String path, Model data, boolean share) throws Exception {
      return getInstance(getPage(path), data, share);
   }
   
   /**
    * This method will create a <code>Viewer</code> using the
    * issued <code>Page</code> object. The resulting viewer
    * is populated with data from the issued data source object. 
    * Changes to the properties of the viewer will be directly
    * inserted into the issued <code>Model</code> instance.
    * 
    * @param page the page template object wrapped by the viewer
    * @param data this contains the initial set of properties 
    * @param share should the data model be inherited or shared
    * 
    * @return an empty viewer that wraps the given template
    */
   private Viewer getInstance(Page page, Model data, boolean share) {
      return new PageViewer(page, share ? data : new Model(data));
   }
}
