/*
 * PageViewer.java December 2003
 *
 * Copyright (C) 2003, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.page;

import simple.template.layout.Viewer;
import simple.page.Model;
import simple.page.Page;
import java.io.PrintWriter;

/**
 * The <code>PageViewer</code> provides an implementation
 * of the <code>Viewer</code> interface. This provides a
 * simple that delegates directly to the <code>Page</code>
 * provides by the <cite>Page</code> templating system.
 * This provides all the methods nessecary to populate the
 * data source used and to render the template content.
 *
 * @author Niall Gallagher
 */
final class PageViewer extends PageDatabase implements Viewer{
        
  /**
    * The template instance used to generate the content.
    */
   private Page page;
   
   /**
    * Constructor for the <code>PageViewer</code> object.
    * This creates a viewer using the issued template object.
    * The viewer is initialized using the properties of the
    * issued <code>Model</code>. These properties can be
    * overridden without affecting the containers database.
    * 
    * @param page template object used to generate output
    * @param data properties used to configure the output 
    */
   public PageViewer(Page page, Model data){
      this.data = data;           
      this.page = page;
   }
   
   /**
    * Displays the contents of the generated template output to
    * the issued <code>Writer</code>. This encapsulates the means
    * of rendering the template to a single method. Internally
    * the properties that are set within the document will be
    * used to configure the template, enabling dynamic output.
    * <p>
    * If there are any problems parsing the template or emitting
    * its contents an exception is thrown. However, if it is
    * successfully processed it will be written to the issued
    * output, which will remain unflushed for performance.
    *
    * @param out the output to write the template rendering to
    *
    * @throws Exception thrown if there is a problem parsing or 
    * emitting the template 
    */   
   public void write(PrintWriter out) throws Exception {
      page.write(out, data);
   }

   /**
    * This is used to acquire a HTTP Content-Type header, which
    * can be used to describe the contents of the viewer. This
    * will typically be the MIME type and character set of the
    * template, for example "text/html; charset=UTF-8". This is
    * provided so that the document can describe the type.
    *
    * @return this returns the content type of the contents
    */ 
   public String getContentType() {
      return page.getContentType();           
   }

   /**
    * This provides the character encoding of the page. This is
    * typically UTF-8, however it can be any supported character
    * encoding for the Java platform. This is used to ensure the
    * conversion from characters to bytes is known.
    * 
    * @return this returns the character encoding of the page
    */    
   public String getCharset() {
      return page.getCharset();           
   }
}
