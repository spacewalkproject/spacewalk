/*
 * PageContainer.java January 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 */

package simple.template.page;

import simple.http.serve.CacheContext;
import simple.template.layout.Layout;
import simple.template.layout.Panel;
import simple.http.serve.Locator;
import simple.http.serve.Context;
import simple.template.Container;
import simple.template.Document;
import simple.page.Workspace;
import simple.page.Model;
import simple.page.Page;

/**
 * The <code>PageContainer</code> provides an implementation of the
 * <code>Container</code> object for <cite>Page</cite> objects. This
 * can be used with a <code>TemplateEngine</code> to provide template
 * documents written in the Java Server Pages (JSP) syntax. This can
 * use either Groovy or Java JSP templates to produce documents.
 *
 * @author Niall Gallagher
 *
 * @see simple.page.Composer
 */
public class PageContainer extends PageDatabase implements Container {

   /** 
    * Workspace used by this container to compile JSP templates.
    */ 
   private Workspace project;
        
   /**
    * Creates the document objects using the specified engine.
    */
   private Layout layout;  
 
   /**
    * Constructor for the <code>PageContainer</code> object. The
    * instance created will use the provided workspace to acquire all
    * JSP pages referenced. Each page is acquired from the source path.
    *
    * @param context the context used to acquire the JSP templates
    *
    * @throws Exception if there is an initialization problem
    */
   public PageContainer(Context context) throws Exception {
      this(new Workspace(context), context);           
   }
   
   /**
    * Constructor for the <code>PageContainer</code> object. The
    * instance created will use the provided workspace to acquire all
    * JSP pages referenced. Each page is acquired from the source path.
    *
    * @param project this is the workspace used to compose templates
    * @param context the context used to acquire the JSP templates
    *
    * @throws Exception if there is an initialization problem
    */
   public PageContainer(Workspace project, Context context) throws Exception{
      this.layout = new PageLayout(project, context);
      this.data = new Model();
      this.project = project;
   }

   /**
    * Determines whether the named template exists. This is used to
    * determine if the <code>lookup</code> method will locate a JSP
    * template given the specified path. If the template is accessible
    * this returns true, otherwise false is returned.
    *
    * @param path this is the path used to locate the JSP template
    *
    * @return true if the template exists, false if it does not
    */
   public boolean exists(String path) {
      return project.getSourceFile(path).exists();
   }

   /**
    * Looks for the named template and wraps the template within
    * a new <code>Document</code> instance. Resolving the location
    * of the template is left up the templating system, typically
    * this requires a file path reference to locate the template.
    * <p>
    * The document created by this method is transient, that is,
    * it is a unique instance. This means that changes to the
    * properties of any created document object affect only that
    * instance. By default this assumes the UTF-8 encoding.
    *
    * @param path this is the path used to locate the JSP template
    *
    * @return the specified template wrapped within a document
    *
    * @throws Exception this is thrown if the is a problem with
    * locating or rendering the specified template
    */
   public Document lookup(String path) throws Exception {
      return lookup(path, true);
   }
   
   /**
    * Looks for the named template and wraps the template within
    * a new <code>Document</code> instance. Resolving the location
    * of the template is left up the templating system, typically
    * this requires a file path reference to locate the template.
    * <p>
    * The document created by this method is transient, that is,
    * it is a unique instance. This means that changes to the
    * properties of any created document object affect only that
    * instance. By default this assumes the UTF-8 encoding.
    *
    * @param path this is the path used to locate the JSP template
    * @param share should the document model be inherited or shared
    *
    * @return the specified template wrapped within a document
    *
    * @throws Exception this is thrown if the is a problem with
    * locating or rendering the specified template
    */
   public Document lookup(String path, boolean share) throws Exception {
      return lookup(path, new Delegate() ,share);
   }

   /**
    * Looks for the named template and wraps the template within
    * a new <code>Document</code> instance. Resolving the location
    * of the template is left up the templating system, typically
    * this requires a file path reference to locate the template.
    * <p>
    * The document created by this method is transient, that is,
    * it is a unique instance. This means that changes to the
    * properties of any created document object affect only that
    * instance. By default this assumes the UTF-8 encoding.
    *
    * @param path this is the path used to locate the JSP template
    * @param data this provides a set of default properties
    * @param share should the data model be inherited or shared
    *
    * @return the specified template wrapped within a document
    *
    * @throws Exception this is thrown if the is a problem with
    * locating or rendering the specified template
    */
   public Document lookup(String path, Object data, boolean share) throws Exception{
      return layout.getPanel(path, data, share);
   }

   /**
    * The <code>Delegate</code> object is used provide documents
    * with their own <code>Model</code>. This enables changes made
    * to the documents properties to be specific to that instance.
    * This will wrap this <code>Container</code> database in such 
    * a way that it is used in a read only manner.
    *
    * @see simple.page.Model
    */
   private class Delegate extends Model {

      /**
       * Constructor for the <code>Delegate</code> object. The
       * constructor delegates to the super class constructor
       * using the containers database as the inner database.
       * This prevent documents from changing that database.
       */
      public Delegate() {
         super(data);
      }
   }
}
