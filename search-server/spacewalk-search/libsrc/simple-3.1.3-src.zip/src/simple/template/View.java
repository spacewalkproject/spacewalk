/*
 * View.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template;

import simple.http.load.LoadingException;
import simple.http.load.LoaderEngine;
import simple.template.Environment;
import simple.template.Document;
import simple.http.serve.Context;
import simple.http.Response;
import simple.http.Request;
import java.io.OutputStream;

/**
 * The <code>View</code> object provides a service controller 
 * implementation for providing a document view. It is used
 * to implement controllers that ultimately render a view for a
 * template. Typically the <code>execute</code> methods are
 * implemented to populate a template document with the objects
 * that are used by the template to render the dynamic content.
 * </p>
 * The <code>lookup</code> and <code>resolve</code> methods are
 * used to acquire the desired template document. This must then
 * be returned for the view to be rendered. If at any stage 
 * during processing and error occurs then an exception may be
 * thrown to the calling method to indicate the problem.
 *
 * @author Niall Gallagher
 */ 
public abstract class View extends Controller {
        
   /**
    * Constructor for the <code>View</code> object. This is used 
    * to create an <code>View</code> implementation that can be 
    * used as a controller service. Any subclass of this can 
    * initialize itself using the <code>prepare</code> method.
    *
    * @param context the context this controller is rooted at
    */    
   public View(Context context) {
      super(context);
   }
   
   /**
    * This <code>process</code> method is used to drive the 
    * <code>execute</code> methods. This will simply invoke the
    * method and write the resulting <code>Document</code> to the
    * responses output. This also sets the HTTP "Content-Type" 
    * header using the name of the target. This will is only set
    * is it has not already been done so. However, this should 
    * not be relied upon and each implementation should set its 
    * own MIME type in order for the charset to be correct.
    * 
    * @param req the HTTP request object representing the client
    * @param resp the HTTP response object to send a reply with
    * 
    * @throws Exception thrown if there is a problem processing  
    */ 
   protected void process(Request req, Response resp) throws Exception {  
      OutputStream out = resp.getOutputStream();    
      Document doc = execute(req, resp); 

      if(!resp.isCommitted()) {
         String type = doc.getContentType();
         
         if(!resp.contains("Content-Type")){
            resp.set("Content-Type", type);
         }
      }
      doc.write(out);
      out.close();
   }

   /**
    * The <code>execute</code> method is used to perform various
    * operations before a template is rendered. This typically
    * collects data that is used to render the template with the
    * information. This encourages the Model View Controller (MVC)
    * architecture to be used, and avoids dealing with the view.
    *
    * @param req the HTTP request object representing the client
    * @param resp the HTTP response object to send a reply with
    * 
    * @return this returns the document that is to be rendered
    *  
    * @throws Exception thrown if there is a problem processing 
    */
   public Document execute(Request req, Response resp) throws Exception {
      return execute(req, resp, resolve(req.getURI()));
   }
   
   /**
    * The <code>execute</code> method is used to perform various
    * operations before a template is rendered. This typically
    * collects data that is used to render the template with the
    * information. This encourages the Model View Controller (MVC)
    * architecture to be used, and avoids dealing with the view.
    * <p>
    * This method is useful when a layout or other such embedding
    * is required. This also avoids having to deal directly with
    * the <code>resolve</code> and <code>lookup</code> methods.
    *
    * @param req the HTTP request object representing the client
    * @param resp the HTTP response object to send a reply with
    * @param doc the document object suggested for processing 
    *       
    * @return this returns the document that is to be rendered
    * 
    * @throws Exception thrown if there is a problem processing 
    */ 
   public Document execute(Request req, Response resp, Document doc) throws Exception {
      throw new UnsupportedOperationException("Override required");
   }
   /**
    * This method is used to retrieve templates using the name or
    * path for that template. This will typically map directly to
    * the <code>Environment</code> object's <code>lookup</code>.
    * However, if desired, extra functionality can be introduced 
    * to provide more useful names for templates, like "failure".
    *
    * @param target the name or path referencing the template
    *
    * @return the <code>Document</code> for the template
    */
   public Document lookup(String target) throws Exception {
      return system.lookup(target);
   }

   /**
    * This method is used to retrieve templates using a specific
    * URI. The URI format is not important, this method should
    * be able to handle absolute and realitive URI formats. The
    * following list of URI strings should be acceptable forms:
    * <pre>
    * 
    * http://www.domain.com/path?query
    * /path;param=value?query
    * /path/file
    *
    * </pre>
    * Like the <code>lookup</code> method this will typically
    * map directly to its counterpart <code>Environment</code>
    * method. However, extra functionality can be introduced to
    * map URI strings to the desired template documents.
    *
    * @param target the URI string referencing the template
    *
    * @return the <code>Document</code> for the template
    */ 
   public Document resolve(String target) throws Exception {
      return system.resolve(target);
   }        
}
