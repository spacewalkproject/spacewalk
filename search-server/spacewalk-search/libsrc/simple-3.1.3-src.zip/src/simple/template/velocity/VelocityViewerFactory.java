/*
 * VelocityVeiwerFactory.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.velocity;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;
import simple.template.layout.ViewerFactory;
import simple.template.layout.Viewer;
import java.io.FileNotFoundException;

/**
 * The <code>VelocityVeiwerFactory</code> resolves a viewer
 * instance from a specified path. The location of the viewer
 * is relative to the user specified <cite>Velocity</cite> 
 * template root. The viewers resolved by this factory object
 * wrap the template located at the specified path. In order 
 * to supply an initial set of data to a created viewer object 
 * a <code>Context</code> instance must be supplied.
 *
 * @author Niall Gallagher 
 */
final class VelocityViewerFactory implements ViewerFactory {
        
   /**
    * The engine used to acquire templates from a root path.
    */
   private VelocityLoader loader;
   
   /**
    * Constructor for the <code>VelocityVeiwerFactory</code>. This
    * creates a factory for creating viewer objects. The engine is
    * used to create and configure all referenced templates which
    * are then wrapped in a <code>Viewer</code> object.
    *
    * @param loader the loader used to acquire the templates 
    */
   public VelocityViewerFactory(VelocityLoader loader) {
      this.loader = loader;
   }

   /**      
    * Retrieves the referenced <code>Template</code> object from
    * the <cite>Velocity</cite> runtime. This method is provided
    * for convenience, to avoid using <code>getTemplate</code> 
    * with the <code>VelocityEngine</code> object. By default
    * this uses UTF-8 character encoding.
    *
    * @param path this is the path used to locate the template
    *
    * @throws FileNotFoundException if the template is not found
    */
   private VelocityTemplate getTemplate(String path) throws Exception {
      return loader.getTemplate(path);
   }
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the <cite>Velocity</cite> runtime, which
    * acquires all resources from a user specified template root.
    * <p>
    * The viewer created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created viewer object affect only that 
    * instance. By default this assumes the UTF-8 encoding. 
    * <p>
    * To provide an initial set of properties to the viewer an
    * <code>Object</code> is used to populate the viewer. All
    * that is required to supply supplemental properties to the
    * viewer is to provide a populated <code>Context</code>.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share shoudl the data model be inherited or shared
    *
    * @throws FileNotFoundException if the template is not found
    */
   public Viewer getInstance(String path, Object data, boolean share) throws Exception {
      return getInstance(path, (Context)data, share);
   }
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the <cite>Velocity</cite> runtime, which
    * acquires all resources from a user specified template root.
    * <p>
    * The viewer created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created viewer object affect only that 
    * instance. By default this assumes the UTF-8 encoding. 
    * <p>
    * To provide an initial set of properties to the viewer a
    * <code>Context</code> is used to populate the viewer. All
    * that is required to supply supplemental properties to the
    * viewer is to provide a populated <code>Context</code>.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share shoudl the data model be inherited or shared
    *
    * @throws FileNotFoundException if the template is not found
    */
   private Viewer getInstance(String path, Context data, boolean share) throws Exception {
      return getInstance(getTemplate(path), data, share);
   }
   
   /**
    * This method will create a <code>Viewer</code> using the
    * issued <code>Template</code> object. The resulting viewer
    * is populated with data from the issued data source object. 
    * Changes to the properties of the viewer will be directly
    * inserted into the issued <code>Context</code> instance.
    * 
    * @param adapter the template object wrapped by the viewer
    * @param data this contains the initial set of properties 
    * 
    * @return an empty viewer that wraps the given template
    */
   private Viewer getInstance(VelocityTemplate adapter, Context data, boolean share) {
      return new VelocityViewer(adapter, share ? data: new VelocityContext(data));
   }
}
