/*
 * VelocityTemplate.java January 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 */

package simple.template.velocity;

import org.apache.velocity.context.Context;
import org.apache.velocity.Template;
import java.io.Writer;

/**
 * The <code>VelocityTemplate</code> object is used to wrap a 
 * template loaded from the templating system. This provides details
 * such as the MIME type and character encoding used by the template.
 *
 * @author Niall Gallagher
 */ 
final class VelocityTemplate {

   /**
    * This is the template that has been loaded by the system
    */         
   private Template template;

   /**
    * This is the MIME type resolved for the template obejct.
    */    
   private String type;   

   /**
    * Constructor for the <code>VelocityTemplate</code> object. This
    * is used to wrap the provided template, and provide details such
    * as the MIME type of the template and its character encoding.
    *
    * @param template this is the template object to be wrapped
    * @param type this is the MIME type for the template
    */   
   public VelocityTemplate(Template template, String type) {
      this.template = template;
      this.type = type;      
   }

   /**
    * This method is used to write the contents of the template to
    * the provided <code>Writer</code>. The data used by the template
    * is provided as a simple hash model, known by the system
    * 
    * @param out this is the writer to write the contents to
    * @param data this is the data used by the template object
    */    
   public void write(Writer out, Context data) throws Exception {
      template.merge(data, out);           
   }

   /**
    * By default the chacacter encoding used by the template is UTF-8.
    * This will provide a string that can be used by the Content-Type
    * HTTP header, it contains the type and a charset attribute.
    *
    * @return this returns the content type for the template
    */    
   public String getContentType() {
      return type + "; charset=UTF-8";           
   }

   /**
    * This returns the character encoding used by the template. This
    * is used when the contents of the template a transformed from
    * characters to bytes. This is used by the Content-Type header.
    *
    * @return this returns the character encoding for the template
    */    
   public String getCharset() {
      return "UTF-8";           
   }   
}
