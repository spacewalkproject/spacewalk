/*
 * Layout.java July 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

/**
 * The <code>Layout</code> object is used to perform a layout
 * given a specific target path. The layout is typically performed
 * based on some configuration information that the instance can
 * load on initialization. Such information could be an XML file 
 * or even a simple Java properties file. The type and means for
 * configuration is left to the developer to decide. 
 * <p>
 * A simple example of a possible layout configuration scheme
 * would be to use a Java properties file to reference templates
 * that could be insterted into the specified target template. So 
 * if the specified target named "index.vm" was referenced, then 
 * the Java properties file "index.vm.properties" could contain 
 * name path pairs which could be used to insert other documents
 * into the original target. In this the referenced template 
 * provides the layout for the inserted template documents.
 *
 * @author Niall Gallagher 
 */ 
public interface Layout {

   /**
    * This method will retreive a <code>Panel</code> object 
    * that implements the layout for the specified target. This
    * document will typically contain other documents referenced
    * within a configuration file. The configuration scheme is
    * independant, and is left for the developer to decide.
    * 
    * @param name this is the target template or layout to use
    * @param data this is the data source used by the template
    * @param share should the data be inherited or unmodified
    */
   public Panel getPanel(String name, Object data, boolean share) throws Exception;
}
