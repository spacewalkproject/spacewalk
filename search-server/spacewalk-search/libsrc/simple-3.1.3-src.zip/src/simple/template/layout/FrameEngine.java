/*
 * FrameEngine.java September 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.http.serve.Context;
import simple.http.serve.Locator;
import java.io.IOException;
import java.io.File;

/**
 * The <code>FrameEngine</code> is used to acquire a referenced 
 * frame. This uses a search path that starts with the global frame
 * configuration file, "layout.xml". If "layout.xml" does not 
 * contain the referenced frame then the context directory is 
 * queried for a file that matches the frame reference name. For
 * example if the reference was "/path/index.xml" then this uses
 * that XML file to check for the frame definition.
 * <p>
 * This resolves frame definitions quickly, whether they are taken
 * from the global layout configuration file or the file system. 
 * It does this by caching all references, which ensures that a
 * minimum of parsing is done. Also, this caches failed references 
 * to that failed hits do not have a performance impact.
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.TileLayout
 */ 
final class FrameEngine implements FrameResolver {

   /**
    * Used to acquire frames from the layout configuration file.
    */             
   private FrameResolver resolver;

   /**
    * Used to acquire frames definitions from the context path.
    */ 
   private FrameFactory factory;

   /**
    * This is used to acquire frames and configuration.
    */ 
   private Context context;

   /**
    * Constructor for the <code>FrameEngine</code> object. This is
    * used to create a frame resolver that acquires frames from
    * both the layout configuration file and the files from within
    * the provided <code>Context</code> object.
    *
    * @param context this is used to locate the frame documents
    */ 
   public FrameEngine(Context context) {
      this(context, context.getLocator());
   }
   
   /**
    * Constructor for the <code>FrameEngine</code> object. This is
    * used to create a frame resolver that acquires frames from
    * both the layout configuration file and the files from within
    * the provided <code>Context</code> object.
    *
    * @param context this is used to locate the frame documents
    * @param lookup this is used to locate configuration files
    */ 
   public FrameEngine(Context context, Locator lookup) {
      this.factory = new FrameFactory(context);           
      this.context = context;
      this.init(lookup);
   }
   
   /** 
    * This will attempt to acquire an XML configuration file that 
    * is used to describe a document layout. The XML file will be
    * located using the <code>Locator</code> supplied. This will 
    * search for the configuration file using the file names 
    * "Layout.xml" and "layout.xml". If the file cannot be found
    * then this will return quietly, and this object will be empty.
    *
    * @param lookup the locator used to locate the configuration
    */
   private void init(Locator lookup) {
      try {
         load(lookup);
      }catch(IOException e){
         return;
      }
   }
   
   /** 
    * This <code>load</code> method attempts to load the XML file
    * file <code>Layout.xml</code> using the given locator. If
    * the configuration file exists then it is used to describe
    * the layout for documents served by the templating system.
    * <p>
    * This will attempt to load the file using the UTF-8 charset
    * so that international characters can be used for patterns 
    * that can be used. This is compatible with ISO-8859-1.
    *
    * @param lookup this is the locator used to discover the file
    *
    * @exception IOException thrown if there is an I/O problem
    */   
   private void load(Locator lookup) throws IOException {
      try {
         load(lookup,"Layout.xml");
      }catch(IOException e) {
         load(lookup,"layout.xml");
      }
   }
   
   /**
    * This will load the named file from within the given path. This
    * is used so that a configuration file can be loaded by a locator
    * using the specified file name. If the XML configuration file
    * cannot be loaded this will throw an <code>IOException</code>. 
    *
    * @param lookup this is the locator used to discover the file
    * @param name this is the name of the configuration file loaded
    *
    * @exception IOException thrown if there is an I/O problem
    */
   private void load(Locator lookup, String name) throws IOException{
      load(lookup, lookup.getFile(name));
   }

   /**
    * This will load the frame configuration from the given file. This
    * is used so that a global set of configurations can be used by 
    * this frame engine. If the configuration data cannot be loaded
    * from the file this will throw an <code>IOException</code> . 
    *
    * @param lookup this is used to load any additional configuration
    * @param file this is the file containing the XML configuration
    *
    * @exception IOException thrown if there is an I/O problem
    */
   private void load(Locator lookup, File file) throws IOException{
      resolver = new FrameParser(file);           
   }

   /**
    * This retrieves a frame definition for the specified target.
    * A frame definition is represented as a <code>Frame</code>
    * object. This object contains the target name, source path,
    * and the tile definitions that can be used to create and
    * populate a template. The target that identifies the frame
    * is typically a URI path, but can be any string identifier.
    *
    * @param name this is the name of the frame definition
    *
    * @return an object that is used to describe the frame
    *
    * @exception IOException thrown if there is an I/O problem
    */
   public Frame getFrame(String name) throws IOException {
      Frame frame = null;
      
      if(resolver != null) {
         frame = resolver.getFrame(name);
      }
      if(frame != null) {
         return frame;              
      }      
      return factory.getInstance(name);
   }
}
