/*
 * PanelFactory.java March 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

/**
 * The <code>PanelFactory</code> serves to resolve a document
 * instance from a specified path. The location of the document
 * is dependant on the implementation. Panels created by an
 * implementation of the <code>PanelFactory</code> typically
 * wrap a <code>Viewer</code> produced from an implementation of
 * the <code>ViewerFactory</code>. This structure ensures that
 * the integration of new templating systems is easy, the system
 * need only adhere to some simple interfaces to be compatible. 
 *
 * @author Niall Gallagher 
 */
interface PanelFactory {
        
   /**
    * Creates a new <code>Panel</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the implementation. The document created
    * by this method is transient, that is, it exists locally only.
    * This means that changes to the properties of any created 
    * document object affect only that instance. All documents
    * retrieved will use the UTF-8 character encoding. 
    * 
    * @param name the name or path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared
    */
   public Panel getInstance(String name, Object data, boolean share) throws Exception;
}
