/*
 * Source.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import java.io.PrintWriter;

/**
 * The <code>Source</code> is used to provide an object for a tile
 * to present within a template. An implementation will provide
 * an object using the primary <code>Layout</code> and the data
 * source used by the template. The data source can be used by 
 * the instance to add objects for the template to use, or to
 * acquire objects to perform some configuration before providing
 * the value that will be used by the tile.
 * <p>
 * A source object is used as a factory of sorts. What it will do
 * is create an object to be used by a <code>Tile</code>. It is
 * the tile object that is inserted into the template directly. 
 * However, the <code>Source</code> is used by the tile to get
 * the object that is to be used or presented by the template.
 *  
 * @author Niall Gallagher
 *
 * @see simple.template.layout.Tile
 */ 
interface Source {

   /**
    * This provides a value that is used by a tile object to
    * present some data, or provide some tool to be used by 
    * the template. The value provided can be referenced
    * from  within the template using a tile object. Objects
    * should enable the <code>toString</code> method so that
    * they can be presented when referenced by the template.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    *
    * @return this is the object that is used by the template
    */ 
   public Object getValue(Layout layout, Object data) throws Exception;

   /**
    * This provides a means for writing the contents of the
    * referenced source in an efficient manner. This matches 
    * the <code>Tile</code> interface in that the same writer
    * can be passed to each source object in a tile layout
    * tree. This allows deep layout trees to cascade well.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    * @param out this is the writer object to write to 
    */ 
   public void write(Layout layout, Object data, PrintWriter out) throws Exception;
}
