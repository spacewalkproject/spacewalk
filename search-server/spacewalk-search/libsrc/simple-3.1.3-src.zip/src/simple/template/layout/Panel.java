/*
 * Panel.java February 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.template.Document;
import java.io.PrintWriter;

/**
 * The <code>Panel</code> object is used to represent a means for a
 * document to be written into a frame definition or screen. This
 * provides a more efficient means for displaying a document as it
 * will allow a single <code>PrintWriter</code> to be shared among
 * several documents. This is particularly useful for JSP templates.
 * 
 * @author Niall Gallagher
 */ 
public interface Panel extends Document {

   /**
    * This is used to write the contents of the document without the
    * need for an adapter, such as an output stream writer. This is
    * a more efficient means of displaying the contents, as the use
    * of <code>toString</code> does not cascade very well when deep
    * layout trees are used. An exception is thrown on error.
    *
    * @param out this is the print writer to write the panel to
    */         
   public void write(PrintWriter out) throws Exception;        
}
