/*
 * DefaultPanelFactory.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.http.serve.Context;

/**
 * The <code>DefaultPanelFactory</code> serves to produce the
 * documents used for templating using a template path or name.
 * This uses a <code>ViewerFactory</code> to hide the details of
 * the templating system used. In this way, this implementation 
 * can interface with many templating systems.
 * <p>
 * The <code>Panel</code> objects produced by this factory will
 * have their MIME types set by the <code>Context</code> provided.
 * This provides a means for developers and users of the system 
 * to specify their own MIME mappings for requested templates.
 *
 * @author Niall Gallagher 
 */
final class DefaultPanelFactory implements PanelFactory {

   /**
    * This interfaces directly with the templating system used.
    */ 
   private ViewerFactory factory;

   /**
    * This is used to acquire MIME mappings for all templates.
    */     
   private Context context;

   /**
    * Constructor for the <code>PanelFactory</code>. This will
    * create a factory for creating document objects. The direct
    * interface for the templating system comes from the provided
    * <code>ViewerFactory</code>, which is used to create and 
    * configure a <code>Viewer</code> for the requested template. 
    *
    * @param factory the factory used to acquire the templates 
    * @param context the context used for MIME type mappings
    */
   public DefaultPanelFactory(ViewerFactory factory, Context context) {
      this.factory = factory;
      this.context = context;
   }
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. The <code>ViewerFactory</code> is used
    * to produce each object, which hides the specifics of the 
    * templating system used to render the template source.
    * <p>
    * The object created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any instance affect that instance alone.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared
    *
    * @return returns a <code>Viewer</code> for the template
    */
   private Viewer getViewer(String path, Object data, boolean share) throws Exception {
      return factory.getInstance(path, data, share);
   }
   
   /**
    * Creates a new <code>Panel</code> object, which wraps the
    * referenced template. The template is provided as an instance
    * of the <code>Viewer</code> interface, which serves to hide
    * the details of the templating system API. The instance used
    * is acquired using the <code>ViewerFactory</code> provided.
    * <p>
    * The document created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created document object affect only that 
    * instance. The resulting document uses UTF-8 encoding. 
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared
    *
    * @return returns a <code>Panel</code> for the template 
    */
   public Panel getInstance(String path, Object data, boolean share) throws Exception {      
      return getInstance(path, getViewer(path, data, share));
   }
   
   /**
    * Creates a new <code>Panel</code> object, which wraps the
    * referenced template. The template is provided as an instance
    * of the <code>Viewer</code> interface, which serves to hide
    * the details of the templating system API.     
    * <p>
    * The document created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created document object affect only that 
    * instance. The resulting document uses UTF-8 encoding.
    * 
    * @param path this is the path used to locate the template
    * @param viewer the object used to interface with the template
    *
    * @return returns a <code>Panel</code> for the template 
    */
   private Panel getInstance(String path, Viewer viewer) throws Exception {
      return new PanelDocument(viewer, path);
   }
}
