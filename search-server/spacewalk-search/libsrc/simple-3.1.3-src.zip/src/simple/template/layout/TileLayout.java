/*
 * TileLayout.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.http.serve.Locator;
import simple.http.serve.Context;
import java.io.PrintWriter;

/**
 * The <code>TileLayout</code> provides a document layout that
 * can be used to build a graph of templates that can be used to
 * create a single view. This is used to generate a layout defined
 * within an XML configuration file that describes a list of
 * documents containing tiles that are to be included into a
 * generated <code>Panel</code> object. The idea is that each 
 * of the described documents, with its tiles, can be added to 
 * another document, such that a graph of documents can be made.
 * Below is an example specification for two documents.
 * <pre>
 * 
 * &lt;?xml version="1.0" encoding="UTF-8"?&gt;
 * &lt;layout&gt;
 *    &lt;document target="example" source="/layout.vm"&gt;
 *       &lt;tile name="name" value="value" type="type"/&gt;
 *    &lt;/document&gt;
 *    &lt;document target="demo" source="example"/&gt;
 * &lt;/layout&gt;
 *
 * </pre>
 * This graph of documents is basically a primary layout template
 * that contains several <code>Panel</code> objects, which in
 * turn may contain several objects. This avoids a template using
 * hardcoded includes, which lead to an unmaintainable codebase.
 * Another advantage to using this layout is that it supports the
 * use of object oriented document definitions, that is, when a
 * specification for a particular document is created another one
 * can be created that extends it. So, using the above example, a
 * document will be created called "demo" that has its source as
 * "example". This document would have the tile "name" without
 * having to declare it within the definition for "demo".
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.Tile
 */ 
public class TileLayout implements Layout {

   /**
    * This is used to acquire the frame definitions specified.
    */ 
   private FrameResolver resolver;
   
   /**
    * This is used to acquire the source objects for templates.
    */ 
   private SourceFactory factory;
  
   /**
    * This provides the interface to the templating system used.
    */ 
   private PanelFactory system;   
   
   /**
    * Constructor for the <code>TileLayout</code> object. A tile 
    * layout is used to create a layout using a  specification 
    * acquired from an XML configuration file. The configuration
    * is acquired from the provided <code>Context</code> object.
    *
    * @param system this is used to acquire the actual templates
    * @param context this is used to load the XML configuration
    */ 
   public TileLayout(PanelFactory system, Context context){
      this.factory = new SourceFactory(context);              
      this.resolver = new FrameEngine(context);                 
      this.system = system;
   }

   /**
    * This method will retrieve a <code>Panel</code> object to
    * represent the specified target. The document returned may
    * be either an empty template document or a layout document
    * that contains various inserted tiles as specified by the
    * XML configuration file. This method will be used to insert
    * a collection of <code>Tile</code> objects into a layout
    * template. The tiles inserted will communicate with a source
    * to acquire its value and present itself within the layout.
    * 
    * @param name this is the name for the document requested
    * @param data this is the data source used by the document
    */ 
   public Panel getPanel(String name, Object data, boolean share) throws Exception{
      Frame frame = resolver.getFrame(name);
      
      if(frame == null) {
         return system.getInstance(name, data, share);              
      }      
      return getPanel(frame, data, share);
   }
   
   /**
    * This method will retrieve a <code>Panel</code> object to
    * represent the specified target. The document returned may
    * be either an empty template document or a layout document
    * that contains various inserted tiles as specified by the
    * XML configuration file. This method will be used to insert
    * a collection of <code>Tile</code> objects into a layout
    * template. The tiles inserted will communicate with a source
    * to acquire its value and present itself within the layout. 
    * 
    * @param frame this is the document definition requested
    * @param data this is the data source used by the document
    */ 
   private Panel getPanel(Frame frame, Object data, boolean share) throws Exception {
      Panel layout = getPanel(frame.getSource(), data, share);
      Definition[] list = frame.getDefinitions();         
      
      for(int i = 0; i< list.length; i++){
         Entry entry = new Entry(list[i], data);
         layout.put(entry.getName(), entry);
      }
      return layout;                    
   }

   /**
    * The <code>Entry</code> object provides an implementation of
    * the <code>Tile</code> interface that can be used for a lazy
    * building of the graph of documents. This ensures that there
    * is no recursion caused when a document references another
    * document. It also ensures that the time taken to build the
    * graph is minimal, only those tiles that are referenced are
    * given any resources to extract the required information. 
    *
    * @see simple.template.layout.Tile
    */ 
   private class Entry implements Tile {

      /**
       * This contains all the information regarding this tile.
       */ 
      private Definition tile;

      /**
       * This is the source that is used to acquire the value.
       */ 
      private Source source;

      /**
       * This is the data source used by the template document.
       */ 
      private Object data;   

      /**
       * Constructor for the <code>Entry</code> object. This is
       * used to create a source object using the definition
       * provided. The <code>Source</code> object provides the
       * data used by the tile to render the data presented.
       *
       * @param tile this is the definition for the source
       * @param data this is the template data source to use
       */ 
      public Entry(Definition tile, Object data) {
         this.source = factory.getInstance(tile);
         this.tile = tile;
         this.data = data;      
      }

      /**
       * This provides the name of the tile as taken from the name
       * of the <code>Definition</code>. This is useful when the
       * tile needs to be inserted into a <code>List</code> as it
       * will allow a template to determine the tile it represents.
       *
       * @return this provides the reference for this tile object 
       */ 
      public String getName() {
         return tile.getName();           
      }

      /**
       * This is used to write the contents of the tile to the given
       * print writer. This provides a much more efficient means to
       * embed documents within a tile definition. Typically this is
       * used by the JSP templating system to render tiles.
       *
       * @param out this is the writer to emit the tile text to
       */ 
      public void write(PrintWriter out) {
         try {
            source.write(TileLayout.this, data, out);                 
         }catch(Exception cause){
            cause.printStackTrace(out);                 
         }
      }
      
      /**
       * This method causes the <code>Source.getValue</code> method
       * to be invoked. This will extract the value from the source
       * when referenced from within a template. This initiates
       * a further branch of the document graph to be created.
       *
       * @return this returns the value taken from the source
       */ 
      public Object getValue() {
         return getValue(data);
      }

      /**
       * This method causes the <code>Source.getValue</code> method
       * to be invoked. This will extract the value from the source
       * when referenced from within a template. This initiates
       * a further branch of the document graph to be created.
       *
       * @param data this is the data source used by the template
       *       
       * @return this returns the value taken from the source
       */
      private Object getValue(Object data) {
         return getValue(TileLayout.this, data);           
      }
      /**
       * This method causes the <code>Source.getValue</code> method
       * to be invoked. This will extract the value from the source
       * when referenced from within a template. This initiates
       * a further branch of the document graph to be created.
       *
       * @param data this is the data source used by the template
       * @param layout this is a reference to this layout object
       *
       * @return this returns the value taken from the source
       */      
      private Object getValue(Layout layout, Object data) {
         try {    
            return source.getValue(layout, data);           
         } catch(Exception cause) {
            return new ExceptionBuffer(cause);
         }         
      }
      
      /**
       * This invokes the <code>toString</code> method of the source
       * value. Typically objects inserted into the template by the
       * document definition are viewable objects, such as headings
       * or other templates. This makes it easy for those values
       * to be presented within a template, a simple reference to
       * the <code>Tile</code> will cause this method to be invoked.
       *
       * @return this returns the string value of this tile object
       */ 
      public String toString() {
         return getValue().toString();           
      }   
   }      
}
