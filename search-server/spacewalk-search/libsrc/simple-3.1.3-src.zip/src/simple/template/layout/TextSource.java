/*
 * TextSource.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.http.serve.Context;
import java.io.PrintWriter;

/**
 * The <code>TextSource</code> object is used to insert some text
 * into the template document. The text included in the template 
 * is provided to the constuctor, this text can then be rendered
 * within the template using the name handle. This provides a 
 * simple string include for the template document.
 * 
 * @author Niall Gallagher
 */ 
final class TextSource implements Source{

   /**
    * This is the value to be included within the template.
    */ 
   private String value;        

   /**
    * Constructor for the <code>TextSource</code> object. This
    * is used to include text values into a template that can be    
    * referenced using its name. This is basically a text include.
    *
    * @param context the context used by the templating system
    * @param value the value to be included in the template
    */ 
   public TextSource(Context context, String value){
      this.value = value;
   }

   /**
    * This provides an object used by a <code>Tile</code> to
    * present a string or property value within the template.
    * The object provided can be referenced by the template
    * using the <code>Tile</code> object that wraps this 
    * source. This facilitates a simple template text include.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    *
    * @return this returns string or property to include
    */    
   public Object getValue(Layout layout, Object data){
      return value == null ? "" : value;
   }        

   /**
    * This provides a efficient means for writing the text value
    * for this source object. This will simply write the text
    * directly to the provided <code>PrintWriter</code> object.
    * If the value is null then an empty string is written.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    * @param out this is the print writer to write the value to
    */ 
   public void write(Layout layout, Object data, PrintWriter out){
      out.print(value == null ? "" : value);           
   }
}
