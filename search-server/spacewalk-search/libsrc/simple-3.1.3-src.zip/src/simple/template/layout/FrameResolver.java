/*
 * FrameResolver.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import java.io.IOException;

/**
 * The <code>FrameResolver</code> resolves a frame definition
 * from a specified target name. The target name is typically a
 * URI path, but can be any string identifier. This identifier is
 * used to locate a frame definition and produce an instance of
 * the <code>Frame</code> interface to represent that definition.
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.FrameBuilder
 */ 
interface FrameResolver {
   
   /**
    * This retrieves a frame definition for the specified target.
    * A frame definition is represented as a <code>Frame</code>
    * object. This object contains the target name, source path,
    * and the tile definitions that can be used to create and
    * populate a template. The target that identifies the frame
    * is typically a URI path, but can be any string identifier.
    *
    * @param target this is the name of the frame definition
    *
    * @return an object that is used to describe the frame
    *
    * @exception IOException thrown if there is an I/O problem
    */
   public Frame getFrame(String target) throws IOException;
}
