/*
 * Viewer.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.template.Database;
import java.io.PrintWriter;

/**
 * A <code>Viewer</code> object represents a template with a 
 * set of properties. This represents a template loaded from some
 * source that can have specific properties set to configure a
 * rendering of the template acquired from the templating system.
 * <p>
 * This interface attempts to encapsulate the functionality 
 * provided by the templating system in an independant manner.
 * This achieves two things, it ensures that the controller is
 * not tightly coupled to the templating system and ensures that
 * firmiliarity with the templating system's API is not required.
 *
 * @author Niall Gallagher
 */
public interface Viewer extends Database {

   /**
    * Displays the contents of the generated template output to
    * the issued <code>Writer</code>. This encapsulates the means
    * of rendering the template to a single method. Internally
    * the properties that are set within the document will be
    * used to configure the template, enabling dynamic output.
    * <p>
    * If there are any problems parsing the template or emitting
    * its contents an exception is thrown. However, if it is
    * successfully processed it will be written to the issued
    * output, which should remain unflushed for performance.
    *
    * @param out the output to write the template rendering to
    *
    * @throws Exception thrown if there is a problem parsing or 
    * emitting the template 
    */  
   public void write(PrintWriter out) throws Exception;

   /**
    * This is used to acquire a HTTP Content-Type header, which
    * can be used to describe the contents of the viewer. This
    * will typically be the MIME type and character set of the
    * template, for example "text/html; charset=UTF-8". This is
    * provided so that the document can describe the type.
    *
    * @return this returns the content type of the contents
    */ 
   public String getContentType();

   /**
    * This provides the character encoding of the page. This is
    * typically UTF-8, however it can be any supported character
    * encoding for the Java platform. This is used to ensure the
    * conversion from characters to bytes is known.
    * 
    * @return this returns the character encoding of the page
    */ 
   public String getCharset();
}
