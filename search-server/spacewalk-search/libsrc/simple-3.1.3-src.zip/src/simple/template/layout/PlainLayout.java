/*
 * PlainLayout.java July 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

/**
 * The <code>PlainLayout</code> object provides an implementation
 * of the <code>Layout</code> interface, which performs no layout. 
 * All documents retrieved from this implementation are directly
 * taken from the provided <code>PanelFactory</code>. This is
 * used if there is no specific implementation suggested. Also it
 * is used when no layout is required by the template engine.
 *
 * @author Niall Gallagher
 */ 
public class PlainLayout implements Layout {

   /**
    * This is the factory that produces the document objects.
    */ 
   private PanelFactory factory;

   /**
    * Constructor for the <code>PlainLayout</code> object. The
    * factory provided to this object is used to retrieve all 
    * requested <code>Dcoument</code> objects, which will remain
    * unmodified by the <code>Layout</code> implementation.
    *
    * @param factory the factory that produces all documents
    */ 
   public PlainLayout(PanelFactory factory) {
      this.factory = factory;      
   }

   /**
    * This method basically acts as an adapter method to the 
    * provided <code>PanelFactory</code>. This will leave all
    * retrieved documents unmodified so that no layout is used.
    * 
    * @param name this is the target template to be retrieved
    * @param data this is the data source used by the template
    * @param share should the data model be inherited or shared
    */ 
   public Panel getPanel(String name, Object data, boolean share) throws Exception {
      return factory.getInstance(name, data, share);           
   }   
}
