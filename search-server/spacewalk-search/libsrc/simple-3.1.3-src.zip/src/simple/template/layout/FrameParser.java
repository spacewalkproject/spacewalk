/*
 * FrameParser.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.util.xml.Node;
import simple.util.xml.Traverser;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.io.File;

/**
 * The <code>FrameParser</code> is used to parse an XML file that
 * contains a simple description of a layout. This is used by the
 * <code>TileLayout</code> to build a graph of templates so that
 * a complex tree of templates can be used to build a single page.
 * This avoids the problems often caused by static includes, which
 * leave large sites with an unmaintainable codebase. An example
 * XML configuration file that this can parse is shown below.
 * <code><pre>
 *
 * &lt;?xml version="1.0" encoding="UTF-8"?&gt;
 * &lt;layout&gt;
 *    &lt;document target="/index.html" source="/layout.vm"&gt;
 *       &lt;tile name="name" value="value" type="type"/&gt;
 *    &lt;/document&gt;
 * &lt;/layout&gt;
 *
 * </pre></code> 
 * If the configuration file follows this format, it can be parsed
 * successfully. This parse will make a best efforts attempt to
 * parse the configuration if the configuration file does not 
 * contain valid XML then an exception will be thrown.
 *
 * @author Niall Gallagher
 */  
final class FrameParser extends Traverser implements FrameResolver {

   /**
    * This is used to load the Source.properties file for the 
    * list of aliases for each source available to a tile.
    */ 
   private static ResourceBundle alias;   
   
   static {      
      try { 
         alias = ResourceBundle.getBundle("simple.template.layout.Source");
      }catch(MissingResourceException e){
         e.printStackTrace();
      }   
   }
           
   /**    
    * This is used to build the list of frame definitions used.
    */ 
   private FrameBuilder list;
   
   /**
    * Constructor for the <code>FrameParser</code> object. This
    * is used to create a parser that will construct the frame
    * definitions for a specific target. The frame definitions
    * are loaded from the provided file, and acquired using
    * this object using a target name or URI path.
    *
    * @param source this is the file that containts the layout
    */ 
   public FrameParser(File source) {
      this.list = new FrameBuilder();            
      this.parse(source);
   }

   /**
    * This will load the named file from within the given file. This
    * is used so that a configuration details can be loaded from the 
    * provided file. If the XML configuration file cannot be loaded 
    * this will throw an <code>Exception</code>. 
    *
    * @param source this is the name of the configuration file loaded
    */
   public void parse(File source) {
      try {          
         parse(source, "utf-8");
      }catch(Exception e) {
         return;              
      }         
   }

   /**
    * This retrieves a frame definition for the specified target.
    * The frame definition is taken from the XML configuration
    * file, which is parsed by this parser. The frame definition
    * contains the target or name of the frame as well as the
    * source template used to render the frame and all of the 
    * tiles that can be included into the template.
    *
    * @param target this is the name of the frame definition
    *
    * @return an object that is used to describe the frame
    */
   public Frame getFrame(String target){
      return list.getFrame(target);           
   }
   
   /**
    * This initializes the parser so that it can be used several
    * times. This clears any previous tokens extracted. This
    * ensures that when the next <code>parse(String)</code> is
    * invoked the list of <code>Frame</code> objects is updated.
    */ 
   protected void start(){
      list.clear();           
   }

   /**
    * This method is used to process all elements extracted from the
    * node object. This is primarily interested in the tile elements
    * extracted from the XML file. If the processed element is a
    * tile then this delegates to the <code>tile</code> method. That
    * method will then extract the require attributes for the tile.
    * 
    * @param node this is the element extracted from the node object
    */ 
   protected void process(Node node) {
      String name = node.getName();

      if(name.equals("tile")){
         tile(node);              
      }
   }

   /**
    * This method is used to commit all elements extracted from the
    * node object. This is primarily interested in the document node
    * extracted from the XML file. If the processed element is a
    * document node then this delegates to the <code>document</code>
    * method, which will extract the required attributes and save
    * the accumulated tile elements associated with the document.
    *
    * @param node this is the element extracted from the node object
    */ 
   protected void commit(Node node) {
      String name = node.getName();
      
      if(name.equals("document")) {
         document(node);              
      }           
   }

   /**
    * This method will extract the document block from the provided
    * text. This expression must contains the target and source used
    * by the document. The target attribute defines how the document
    * is located and the soruce attribute represents the tile or
    * template that the document extends. The BNF is as follows.
    * <pre>
    * 
    *    document = "&lt;" "document" target source "&gt;"
    *    tile     = "&lt;" tile name value type "/" "&gt;"
    *    close    = "&lt;" "/" "document" "&gt;"
    *    target   = "target" "=" token
    *    source   = "source" "=" token
    *    name     = "name" "=" token
    *    value    = "value" "=" token
    *    type     = "type" "=" token
    *    
    * </pre>
    * This method is invoked at the end of processing of the element.
    * Processing this an the end of evaluation of a document allows
    * the document data structures to be saved by target name.
    *
    * @param node this is an element representing a document node
    */    
   private void document(Node node) {
      String target = node.getAttribute("target");
      String source = node.getAttribute("source");      

      if(target != null) {
         list.save(target, source);              
      }
   }

   /**
    * This method will extract a tile XML tag from the provided
    * text. This expression must contain the name, value, and type
    * attributes to be extracted successfully. The expression, 
    * should look like the XML BNF expression described below.
    * <pre>
    * 
    *    parse = "&lt;" "tile" name value type "/" "&gt;"
    *    name  = "name" "=" token
    *    value = "value" "=" token
    *    type  = "type" "=" token
    *
    * </pre>
    * The order the attributes appear within the tile tag is not
    * important. However, if an attribute is missing its value will
    * be evaluated to be equal to null. This will insert the tile
    * and clear all buffers used once the parsing has finished.
    *
    * @param node this is an element representing a tile node
    */    
   private void tile(Node node) {
      String name = node.getAttribute("name");
      String value = node.getAttribute("value");
      String type = node.getAttribute("type");

      if(name != null) {
         list.insert(new Entry(name, value, type));              
      }
   }

   /**
    * The <code>Entry</code> object provides an implementation of 
    * the <code>Definition</code> interface. This is used to group 
    * all the details of an tile from a an XML element within
    * the configuration file. This will contain the name, value,
    * and type of source to insert into the document.
    */ 
   private class Entry implements Definition {
           
      /**
       * Contains the value provided to the source object.
       */ 
      private String value;
      
      /**
       * Contains the name of the tile to be included.
       */ 
      private String name;

      /**
       * Contains the class name of source to be created.
       */ 
      private String type;

      /**
       * Constructor for the <code>Entry</code> object. This is
       * used to group all the information needed to create and
       * insert a <code>Source</code> implementation.
       * 
       * @param name this is the string representing the name
       * @param value this is the string representing the value
       * @param type this is the string representing the type  
       */         
      public Entry(String name, String value, String type) {
         this.value = value;
         this.type = type;
         this.name = name;
      }
      
      /**
       * This provides the fully qualified class name for the
       * source inserted into the template. This is used to
       * instantiate the <code>Source</code> implementation
       * so that it can be included in the rendered template.
       *
       * @return this returns the class name of the source
       */ 
      public String getType(){
         try {              
            return alias.getString(type);
         }catch(MissingResourceException e){
            return type;                  
         }            
      } 
      
      /**
       * This provides the name of the tile to be included into
       * the template. The name is used as a handle within the
       * template to reference the included source. If the tile
       * needs to be displayed the name is used by the template.
       *
       * @return this returns the name for the source object
       */ 
      public String getName(){
         return name;  
      }
      
      /**
       * This provides the value to the source created for the
       * tile. The value is used by the source object so that it 
       * can be configured in such a way to provide the correct
       * output once it has been referenced by the template.       
       * 
       * @return this returns the value used by the source
       */ 
      public String getValue(){
         return value;              
      }
   }
}


