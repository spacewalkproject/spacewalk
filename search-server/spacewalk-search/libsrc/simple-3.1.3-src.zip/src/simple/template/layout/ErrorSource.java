/*
 * ErrorSource.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import java.io.PrintWriter;

/**
 * The <code>ErrorSource</code> is used to insert a error report
 * into the template document. This is used as a place holder 
 * for a source, which could not be instantiated, either because
 * the class was not available or because the constructor was 
 * not compatible. This will return a description of the error.
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.SourceFactory
 */ 
final class ErrorSource implements Source{

   /**
    * This is used to describe the problem that has occured.
    */ 
   private Throwable cause;        

   /**
    * Constructor for the <code>ErrorSource</code> object. This
    * implementation is used when a source of another type could
    * not be instantiated for some reason. This will use the
    * <code>Throwable</code> to generate the error description.
    * 
    * @param cause used to describe the error that has occured
    */ 
   public ErrorSource(Throwable cause){
      this.cause = cause;
   }

   /**
    * This provides an object used by a <code>Tile</code> to
    * present an error message the template. The error message
    * is presented by the template using the <code>Tile</code>
    * object that wraps this source. This facilitates a simple 
    * error reporting system for sources that cannot be found.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    *
    * @return this returns a description of the problem
    */   
   public Object getValue(Layout layout, Object data){
      return new ExceptionBuffer(cause).getCause();
   }

   /**
    * This is used to write the stack trace of the error to the
    * print writer object. This provides a more efficient means
    * to display errors as an exception buffer is not required
    * to capture the output. This is typically used by the JSP
    * template framework for efficient display of exceptions.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    * @param out this is the print writer used for display
    */  
   public void write(Layout layout, Object data, PrintWriter out){
      cause.printStackTrace(out);           
   }   
}
