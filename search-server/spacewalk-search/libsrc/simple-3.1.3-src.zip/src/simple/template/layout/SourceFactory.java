/*
 * SourceFactory.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import java.lang.reflect.Constructor;
import simple.http.serve.Context;

/**
 * The <code>SourceFactory</code> object is used to create sources
 * that are used by a template. This uses the data provided by a
 * <code>Definition</code> to create an object of the named type.
 * The object is created using the value string provided by the
 * definition. The templating system <code>Context</code> object 
 * and the definition value object are passed to a two argument
 * constructor for the <code>Source</code> implementation. The
 * type of the object is determined by the <code>getType</code>
 * method within the <code>Definition</code> object supplied.
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.Source
 */ 
final class SourceFactory {

   /**
    * This is the context used by the templating system.
    */         
   private Context context;        
      
   /**
    * Constructor for the <code>SourceFactory</code> object. This
    * creates a factory that can be used to populate templates with
    * source objects. The <code>Context</code> object allows source
    * instances to acquire files from the file system directory.
    *
    * @param context the context used by the templating system 
    */    
   public SourceFactory(Context context) {
      this.context = context;           
   }
   
   /**
    * This method is used to create a <code>Source</code> that is
    * used to generate an object to be used by a template tile.
    * The definition provided is extracted from the configuration
    * file used to describe the layout for a specific target. It
    * contains the name, value, and type of the source, which are
    * used to provide the name of the tile that wraps the created
    * source. When the tile is referenced within the template it
    * contacts the source, which is used to produce an object.
    * 
    * @param tile this is used to create the source object
    */ 
   public Source getInstance(Definition tile) {
      String className = tile.getType();
      String value = tile.getValue();
      
      try {
         Object[] list = new Object[]{context, value};
         return getInstance(className, list);
      }catch(Exception cause) {
         return new ErrorSource(cause);              
      }
   }
   
   /**
    * This is used to create a <code>Source</code> instance with 
    * the issued class name. The class name issued represents a
    * fully qualified package name for the object implementation.
    * The implementation must contain a constructor that takes 
    * two arguments, a <code>Context</code> object and a string
    * value. If the constructor does not exist this method will
    * throw an exception.
    * 
    * @param className this is the name of the implementation
    * @param list represents the arguments to the constructor
    *
    * @return an instance of the <code>Source</code> object
    */
   private Source getInstance(String className, Object[] list) throws Exception{
      Constructor method = getConstructor(className);
      return (Source)method.newInstance(list);
   }
   
   /**
    * Here a <code>ClassLoader</code> is selected to load the class.
    * This will load the class specified using the loader used to 
    * load this class. If there are no problems in loading the class
    * a <code>Constructor</code> is created from the loaded class.
    * <p>
    * The constructor for any <code>Source</code> implementation must
    * contain a two argument constructor that takes two arguments, a
    * <code>Context</code> object and a string. If this constructor
    * does not exist this method will throw an exception.
    * 
    * @param className the name of the source implementation 
    *
    * @return this returns a constructor for the specified class
    */   
   private Constructor getConstructor(String className) throws Exception {
      return getConstructor(Class.forName(className,
         false, SourceFactory.class.getClassLoader()));
   }  
   
   /**
    * This loads the class for the <code>Source</code> provides
    * the standard constructor for the implementation. This will
    * load the <code>Class</code> for the implementation provided
    * that that implementation has a two argument constructor that
    * takes a <code>Context</code> and a string. If the constructor 
    * does not exist an exception is thrown by this method.
    * 
    * @param type this is implementation that is to be instantiated
    *
    * @return the standardized object <code>Constructor</code> 
    *
    * @exception Exception if the constructor could not be created
    */
   private Constructor getConstructor(Class type) throws Exception {
      return type.getDeclaredConstructor(
       new Class[]{Context.class, String.class});
   }   
}

