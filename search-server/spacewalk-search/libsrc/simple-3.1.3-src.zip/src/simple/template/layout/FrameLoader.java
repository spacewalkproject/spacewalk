/*
 * FrameLoader.java September 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.http.serve.Context;
import java.io.IOException;
import java.io.File;

/**
 * The <code>FrameLoader</code> is used to load an parse individual
 * frames from unique XML configurations. This complements the global
 * frame definitions within the "layout.xml" configuration and allows
 * frames to exist in files of the same name as the frame. This has 
 * a number of advantages, in particular it avoids having all
 * configuration within a single XML document. Having individual frame
 * documents provides a cleaner and quicker means to create frames.
 *
 * @author Niall Gallagher
 */ 
final class FrameLoader implements FrameResolver {

   /**
    * Provides access to the context directory for configuration.
    */         
   private Context context;

   /**
    * Constructor for the <code>FrameLoader</code> object. This
    * requires a context object in order to associate a frame name
    * to a file within the context directory. The frame name is
    * typically a normalized URI path such as "/path/Frame.xml".
    *
    * @param context this is the context for the template system
    */ 
   public FrameLoader(Context context) {
      this.context = context;            
   }

   /**
    * This retrieves a frame definition for the specified target.
    * A frame definition is represented as a <code>Frame</code>
    * object. This object contains the target name, source path,
    * and the tile definitions that can be used to create and
    * populate a template. The target that identifies the frame
    * is typically a URI path, but can be any string identifier.
    *
    * @param path this is the name of the frame definition
    *
    * @return an object that is used to describe the frame
    *
    * @exception IOException thrown if there is an I/O problem
    */
   public Frame getFrame(String path) throws IOException {
      return getResolver(path).getFrame(path);
   }

   /**
    * This retrieves a frame resolver that can be used to load
    * frame definitions from the specified file. This will use
    * the file system <code>Context</code> to locate the source
    * which will then be loaded and initialized with frames.
    * 
    * @param path this is the location of the XML definition
    *
    * @return this is used to acquire a resolver from the file
    *
    * @exception IOException thrown if there is an I/O problem
    */ 
   private FrameResolver getResolver(String path) throws IOException {
      return new FrameParser(context.getFile(path));           
   }
}
