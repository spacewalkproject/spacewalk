/*
 * PanelSource.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.http.serve.Context;
import java.io.PrintWriter;

/**
 * The <code>PanelSource</code> is used to insert a named
 * document into the template. This will use the value it has
 * been provided to acquire a <code>Panel</code> object from
 * the <code>Layout</code>. This is essentially used to build 
 * the graph of documents used to compose the tile layout.
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.TileLayout
 */ 
final class PanelSource implements Source{

   /**
    * This is the name for the document to be included.
    */ 
   private String value;        

   /**
    * Constructor for the <code>PanelSource</code> object. 
    * This is provided with the templating system context and
    * the tile definition value used to reference the template
    * that is to be provided by this source implementation.
    * 
    * @param context the context used by the templating system
    * @param value the value to be included in the template    
    */ 
   public PanelSource(Context context, String value){
      this.value = value;
   }

   /**
    * This provides an object used by a <code>Tile</code> to
    * present another template within the template. The template
    * provided can be referenced by the template after it has
    * been produced by the <code>Tile</code> object that wraps 
    * it. This will basically produce a <code>Panel</code>.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    *
    * @return this returns the document object to be included 
    */ 
   public Object getValue(Layout layout, Object data) throws Exception{
      return layout.getPanel(value, data, false);
   }

   /**
    * This provides an efficient means for cascading documents as
    * the <code>toString</code> method is avoided. This allows a
    * single print writer to be shared among a collection of
    * documents within a deep tile graph. This is the preferred
    * means for displaying a document for the JSP templates.
    *
    * @param layout the layout used to acquire all documents
    * @param data this is the data source used by the template
    * @param out this is the print writer to emit the panel to
    */ 
   public void write(Layout layout, Object data, PrintWriter out) throws Exception{
      layout.getPanel(value, data, false).write(out);           
   }   
}
