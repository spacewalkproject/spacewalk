/*
 * FrameBuilder.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The <code>FrameBuilder</code> is used to create definitions for
 * frames from provided <code>Definition</code> objects. This will
 * accumulate all tile definitions provided until the frame can be
 * saved with a call to the <code>save</code> method. Once saved 
 * the frame is represented as a <code>Frame</code> object, which
 * contains all information regarding the frame. All frames can be
 * acquired using the frame target name.
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.FrameParser
 */ 
final class FrameBuilder implements FrameResolver {

   /**
    * Contains all built frame objects stored by a target name.
    */ 
   private Map frames;

   /**
    * Contains the tiles definitions used by the built frame.
    */ 
   private List tiles;
   
   /**
    * Constructor for the <code>FrameBuilder</code> object. This
    * is used to create a builder for frame specifications. This 
    * will allow a set of tile definitions to be built up over a 
    * series of inserts, when all definitions for the frame are
    * inserted the frame specification can be saved, and used.
    */ 
   public FrameBuilder() {
      this.tiles = new ArrayList();
      this.frames = new HashMap();
   }
   
   /**
    * This retrieves the frame object for the specified target.
    * A frame is represented as a <code>Frame</code> object. 
    * This object contains the target name, source path, and the
    * and the tile definitions that can be used to create and
    * populate a template. The target that identifies the frame
    * is typically a URI path, but can be any string identifier.
    *
    * @param target this is the name of the frame definition
    *
    * @return an object that is used to describe the frame
    */   
   public Frame getFrame(String target) {
      return (Frame)frames.get(target);           
   }

   /**
    * This method is used to save the frame object with all of
    * the currently inserted tile definitions. The definitions
    * that have been added to this <code>FrameBuilder</code> are
    * stored under within frame identified by the given target
    * name. This ensures that the frame contains a target name,
    * a source template, and a list of tile definitions.
    * 
    * @param target this is the target specified for this frame
    * @param source this is the source specified for this frame
    */        
   public void save(String target, String source){                 
      save(target, new Entry(target, source));           
   }

   /**
    * This method is used to save the frame object with all of
    * the currently inserted tile definitions. The definitions
    * that have been added to this <code>FrameBuilder</code> are
    * stored under within frame identified by the given target
    * name. This ensures that the frame contains a target name,
    * a source template, and a list of tile definitions.
    * 
    * @param target this is the target specified for this frame
    * @param frame this is the frame that is stored by target
    */        
   private void save(String target, Frame frame) {
      frames.put(target, frame);
      tiles.clear();
   }

   /**
    * This method will add a tile definition to the builder so the
    * frame objects can be saved with a list of definitions. The
    * frame must have a list of <code>Definition</code> objects,
    * which are inserted into the source template. These objects 
    * are created using the properties provided by the definition.
    * The definitions added here are used only be the saved frame.
    *
    * @param tile this is the definition to be added to a frame
    */ 
   public void insert(Definition tile){
      tiles.add(tile);
   }

   /** 
    * Clears the <code>FrameBuilder</code> so that it can be used
    * a second time to generate a new list of tile definitions.
    * This will basically clear the currently saved definitions
    * so that they will not be included into the next frame.
    */ 
   public void clear() {
      frames.clear();
      tiles.clear();
   }

   /**
    * This <code>Entry</code> object is used to represent the frame
    * objects created by this builder. Each instance is stored by
    * target name so that it can be acquired by that name, enabling 
    * the template to act as a layout. This contains all definitions
    * taken from the XML configuration file, as well as the source
    * template or frame used to render the frame specification.
    *
    * @see simple.template.layout.Frame
    */ 
   private class Entry implements Frame {

      /**
       * Contains a cache of the definitions should they be used.
       */            
      private Definition[] cache;
      
      /**
       * Contains the target name as taken from the configuration.
       */ 
      private String target;
      
      /**
       * Contains the source name as taken from the configuration.
       */ 
      private String source;

      /**
       * Contains all tile definitions contained by this frame.
       */ 
      private List local;      

      /**
       * Constructor for the <code>Entry</code> object. This object
       * is used to represent a frame definition, which has been
       * built from a specification within the XML configuration.  
       *
       * @param target this is the target name of this frame
       * @param source this is the template source for the frame
       */ 
      public Entry(String target, String source) {
         this.local = new ArrayList(tiles);
         this.target = target;
         this.source = source;         
      }
      
      /**
       * The target is the name or path used to reference the frame.
       * The target is typically a URI path that acts as an alias 
       * for the frame. For example "/index.html" could be used to
       * as an alias to a template "/index.vm", which could then be
       * rendered with a collection of sources to make a page.
       *
       * @return the target name of frame thats is defined by this
       */ 
      public String getTarget() {
         return target;              
      }
      
      /**
       * The source is the name of the template layout that is used
       * to display the frame. This must be a path that identifies
       * the template within the underlying file system. The path
       * must be in a format that is understood by the templating
       * system, and typically should be in the URI path format.
       *
       * @return the layout document used to render the frame
       */ 
      public String getSource() {
         return source;              
      }
      
      /**
       * This returns the list of definitions that were inserted 
       * into the frame. The definition describes the source that
       * can be extracted and placed in to the layout template.
       * The extracted object will typically be viewable in that 
       * it will implement the <code>toString</code> method.
       *
       * @return the list of definitions describing the frame
       */       
      public Definition[] getDefinitions() {
         if(cache == null) {
            cache = getDefinitions(local);                 
         }              
         return cache;
      }
      
      /**
       * This returns the list of definitions that were inserted 
       * into the frame. The definition describes the source that
       * can be extracted and placed in to the layout template.
       * The extracted object will typically be viewable in that 
       * it will implement the <code>toString</code> method.
       *
       * @return the list of definitions describing the frame
       */ 
      private Definition[] getDefinitions(List list) {
         Definition[] copy = new Definition[list.size()];

         for(int i = 0; i < list.size(); i++){
            copy[i] = (Definition)list.get(i);
         }
         return copy;
      }
   }   
}
