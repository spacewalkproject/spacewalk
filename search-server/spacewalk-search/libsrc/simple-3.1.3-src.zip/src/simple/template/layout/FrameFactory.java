/*
 * FrameFactory.java September 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.util.cache.CacheList;
import simple.http.serve.Context;
import java.io.IOException;
import java.io.File;

/**
 * The <code>FrameFactory</code> object is used to acquire frames 
 * from the context directory. For each frame referenced a document
 * from the context directory of the same name is queried. If the 
 * file exists then it is parsed and the frame is extracted. This
 * does not associate a file extension to a frame document, so 
 * every file referenced is parsed. This can create a big overhead
 * for the system, so each file referenced is cached so that when
 * it is referenced again it does not have to be parsed.
 * 
 * @author Niall Gallagher
 *
 * @see simple.template.layout.FrameParser
 */ 
final class FrameFactory {

   /**
    * This will load and parse the referenced frame documents.
    */             
   private FrameLoader loader;

   /**
    * This is the context used to acquire frame documents.
    */ 
   private Context context;

   /**
    * Each frame document is cached so it is not reparsed.
    */ 
   private CacheList cache;

   /**
    * Constructor for the <code>FrameFactory</code> object. This 
    * uses the context provided to resolve the frame references to
    * files within the underlying file system. The context is also
    * used to locate configuration files needed by the frames.
    *
    * @param context this is the context used to acquire frames
    */ 
   public FrameFactory(Context context) {
      this(context, 1024);           
   }
   
   /**
    * Constructor for the <code>FrameFactory</code> object. This 
    * uses the context provided to resolve the frame references to
    * files within the underlying file system. The context is also
    * used to locate configuration files needed by the frames.
    *
    * @param context this is the context used to acquire frames
    * @param size this is the size of the frame cache used
    */ 
   public FrameFactory(Context context, int size) {   
      this.loader = new FrameLoader(context);      
      this.cache = new CacheList(size);     
      this.context = context;
   }
   
   /**
    * This retrieves a frame definition for the specified target.
    * A frame definition is represented as a <code>Frame</code>
    * object. This object contains the target name, source path,
    * and the tile definitions that can be used to create and
    * populate a template. The target that identifies the frame
    * is typically a URI path, but can be any string identifier.
    *
    * @param path this is the name of the frame definition
    *
    * @return an object that is used to describe the frame
    *
    * @exception IOException thrown if there is an I/O problem
    */
   public Frame getInstance(String path) throws IOException {
      Object data = cache.lookup(path);
      Entry entry = (Entry)data;
      
      if(entry == null) {
         entry = getEntry(path);
      }
      if(entry.isModified()) {
         entry = getEntry(path);
      }
      return entry.getFrame();           
   }

   /**
    * This retrieves an <code>Entry</code> for the frame file. The
    * entry object contains information such as the modification 
    * time of the file, and whether it exists or not. This allows
    * this factory to determine whether a cached frame is valid.
    *
    * @param path this is the name of the frame definition
    *
    * @return an object that is used to represent the frame
    *
    * @exception IOException thrown if there is an I/O problem
    */ 
   private Entry getEntry(String path) throws IOException {
      File file = context.getFile(path);           
      Entry entry = getEntry(path, file);
           
      if(entry != null) {           
         cache.insert(path, entry);            
      }
      return entry;      
   }
   
   /**
    * This retrieves an <code>Entry</code> for the frame file. The
    * entry object contains information such as the modification 
    * time of the file, and whether it exists or not. This allows
    * this factory to determine whether a cached frame is valid.
    *
    * @param path this is the name of the frame definition
    * @param file this is the file used to reference the frame 
    *
    * @return an object that is used to represent the frame
    * 
    * @exception IOException thrown if there is an I/O problem
    */
   private Entry getEntry(String path, File file) throws IOException {
      Frame frame = loader.getFrame(path);
      return new Entry(file, frame);
   }

   /**
    * This <code>Entry</code> object is used to gather associated
    * properties together so that the status of the frame document
    * can be determined quickly. This will contain information
    * such as the file existence and the last modification date
    * of the file at the time it was used to generate the frame.
    *
    * @see java.io.File#lastModified
    */
   private class Entry {
   
      /**
       * This is the template that has been generated.
       */
      public Frame frame;

      /**
       * This represents the source file for the frame.
       */
      public File file;

      /**
       * This is the last modification date of the file.
       */
      public long stamp;

      /**
       * This is used to determine whether the file exists.
       */
      public boolean exist;

      /**
       * Constructor for the <code>Entry</code> object. This uses
       * the given file reference to gather properties regarding
       * the current state of the file, such as modification date.
       *
       * @param file this is the file reference to the frame
       * @param frame this is the frame object that was created
       */       
      public Entry(File file, Frame frame){
         this(file, frame, file.exists());
      }

      /**
       * Constructor for the <code>Entry</code> object. This uses
       * the given file reference to gather properties regarding
       * the current state of the file, such as modification date.
       *
       * @param file this is the file reference to the frame  
       * @param frame this is the frame object that was created
       * @param exist this is true if the file actually exists
       */   
      public Entry(File file, Frame frame, boolean exist){
         this.stamp = file.lastModified();
         this.frame = frame;
         this.exist = exist;
         this.file = file;
      }

      /**
       * Determines whether the file represented by this object 
       * has changed. This performs a check to determine whether 
       * the file has been deleted or whether the file has been 
       * changed. If either condition is true this returns true. 
       *
       * @return returns true if the frame file has changed
       */
      public boolean isModified(){
         if(exist != file.exists()){
            return true;
         }
         if(stamp != file.lastModified()){
            return true;
         }
         return false;
      }

      /**
       * This returns the frame object created from the referenced
       * file. This cane be either a valid frame object or null
       * depending on the referenced file. If this is null then it
       * ensures that the invalid reference is not reparsed.
       *
       * @return null for an invalid file, otherwise a frame
       */ 
      public Frame getFrame() {
         return frame;
      }
   }
}
