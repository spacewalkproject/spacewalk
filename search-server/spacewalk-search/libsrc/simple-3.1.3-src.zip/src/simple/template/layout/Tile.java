/*
 * Tile.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import java.io.PrintWriter;

/**
 * The <code>Tile</code> object is used to represent a value that
 * has been acquired from a <code>Source</code>. The reason the 
 * source value cannot be entered directly into the template is 
 * because if there are ever extentions to this framework they 
 * need to be made in a way that will not break compatibility with
 * existing implementations. Also, directly submitting the source
 * value means that the full graph of documents needs to be made
 * before anything is referenced within the template.
 * <p>
 * This object allows a lazy approach to be taken with regards
 * to the graph building process. Only tiles that are referenced
 * or used within the template will need their source value, and
 * so, only those tiles will extract the source value. Another 
 * benifit to this is that it will reduce the problems caused
 * with recursive references. If only nodes referenced within
 * the template acquire the source value, then all documents can
 * have references to themselves without initiating recursion.
 * 
 * @author Niall Gallagher
 */ 
public interface Tile {

   /**
    * This provides the name of the tile which is the same name
    * as the <code>Source</code> it wraps. This is useful if the
    * tile needs to be inserted into a <code>List</code> as it
    * will allow a template to determine the tile it represents.
    *
    * @return this provides the reference for this tile object 
    */ 
   public String getName();        

   /**
    * This is used to write the contents of the tile to the
    * provided writer. The use of the print writer allows for
    * a much more efficient means for displaying tiles. This is
    * especially benificial when it is used with JSP templates.
    *
    * @param out this is the print writer to write the tile to
    */ 
   public void write(PrintWriter out);

   /**
    * This method causes the <code>Source.getValue</code> method
    * to be invoked. This will extract the value from the source
    * when referenced from within a template. This initiates
    * a further branch of the document graph to be created.
    *
    * @return this returns the value taken from the source
    */ 
   public Object getValue();

   /**
    * This invokes the <code>toString</code> method of the source
    * value. Typically objects inserted into the template by the
    * document definition are viewable objects, such as headings
    * or other templates. This makes it easy for those values
    * to be presented within a template, a simple reference to
    * the <code>Tile</code> will cause this method to be invoked.
    *
    * @return this returns the string value of this tile object
    */ 
   public String toString();
}
