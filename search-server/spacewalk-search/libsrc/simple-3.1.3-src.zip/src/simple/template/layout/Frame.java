/*
 * Frame.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

/**
 * The <code>Frame</code> object is used to represent a frame that
 * contains tile definitions used to provide data for the layout.
 * This contains the target name and the source template for the 
 * frame. All tile definitions owned by the frame will be used to
 * create <code>Source</code> objects, which provide data that is
 * inserted into the template. The source template must be a valid
 * template path reference or the name of another frame object as
 * described in the XML configuration.
 *
 * @author Niall Gallagher
 *
 * @see simple.template.layout.Definition
 * @see simple.template.layout.Source
 */ 
interface Frame {

   /**
    * The target is the name or path used to reference the frame.
    * The target is typically a URI path that acts as an alias 
    * for the frame. For example "/index.html" could be used to
    * as an alias to a template "/index.vm", which could then be
    * rendered with a collection of tile objects to make a page.
    *
    * @return the target name of this frame object definition
    */ 
   public String getTarget();

   /**
    * The source is the name of the template layout that is used
    * to render this frame. This must be a path that identifies
    * the template within the underlying file system. The path
    * must be in a format that is understood by the templating
    * system, and typically should be in the URI path format.
    *
    * @return the layout document used to render the frame
    */ 
   public String getSource();

   /**
    * This returns the list of tile definitions that are used to
    * generate the layout template. The definition describes the
    * source object used to provide data to the layout template.
    * Each <code>Definition</code> object is used to create the
    * source object, which will be placed into the template. 
    *
    * @return the list of definitions used to by this frame
    */ 
   public Definition[] getDefinitions();
}
