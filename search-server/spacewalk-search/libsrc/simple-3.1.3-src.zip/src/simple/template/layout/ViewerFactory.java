/*
 * DocumentFactory.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import simple.http.serve.Index;

/**
 * The <code>ViewerFactory</code> serves to resolve a template
 * view from a specified path. The location of the template is
 * dependant on the implementation. This is used to interface
 * directly with the templating system used so that the API can
 * be hidden under a known interface, the <code>Viewer</code>.
 *
 * @author Niall Gallagher 
 */
public interface ViewerFactory {
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the implementation. The view created by
    * this method is transient, that is, it exists locally only.
    * This means that changes to the properties of any created 
    * <code>Viewer</code> object affect only that instance. 
    * <p>
    * To provide an initial set of properties to the template a
    * data source is provided. The type of data source used will 
    * be implementation dependant.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared
    */        
   public Viewer getInstance(String path, Object data, boolean share) throws Exception;
}
