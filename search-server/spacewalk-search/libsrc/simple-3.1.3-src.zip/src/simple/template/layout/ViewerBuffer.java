/*
 * ViewerBuffer.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.layout;

import java.io.StringWriter;
import java.io.PrintWriter;
import java.io.Writer;

/**
 * The <code>ViewerBuffer</code> object is used to encapsulate a
 * templates contents, such that the <code>Viewer</code> content
 * can be easily converted to a string. This is provided so that
 * the <code>Document.toString</code> method can produce the
 * content of a template as a string, which can be useful if a
 * template object is to be embedded within a template object.
 * This will refresh the data produced by the template on every 
 * use, ensuring that the content is up to date.
 *
 * @author Niall Gallagher 
 */
final class ViewerBuffer extends StringWriter {

   /**   
    * This is the buffer used to capture the template output.
    */
   private StringBuffer text;

   /**
    * This is required to capture the viewer template output.
    */ 
   private PrintWriter out;
   
   /**
    * The template used to generate this buffers contents.
    */ 
   private Viewer source;

   /**
    * Constructor for the <code>ViewerBuffer</code>. This is
    * used to capture the output of the issued template, which
    * will be updated on every call to <code>toString</code>.
    *
    * @param source the template to capture the output from
    */   
   public ViewerBuffer(Viewer source) {
      this.out = new PrintWriter(this);
      this.text = getBuffer();
      this.source = source;      
   }

   /**
    * This method is used so that if there is an exception the
    * stack trace can be printed in place of the document. This
    * is very important when it comes to tracking down bugs
    * within template documents and template properties.
    *
    * @param cause this is the cause of the template error
    *
    * @return returns a string representation of the error
    */ 
   private String toString(Exception cause) {
      return new ExceptionBuffer(cause).getCause();           
   }
   
   /**
    * Generates an up to date copy of the templates contents.
    * This is used by the <code>ViewerBuffer</code> to render 
    * the contents of the source template. If there are any
    * exceptions thrown during rendering this returns null.
    *
    * @return an up to date copy of the templates contents
    */
   public String toString() {
      if(text.length() > 0){
         text.setLength(0);
      }
      try {
         source.write(out);
      } catch(Exception cause) {
         return toString(cause);         
      }
      return text.toString();         
   }
}
