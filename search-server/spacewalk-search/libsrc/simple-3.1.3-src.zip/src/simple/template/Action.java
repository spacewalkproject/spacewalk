/*
 * Action.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template;

import simple.http.serve.Context;
import simple.http.serve.Resource;
import simple.http.Response;
import simple.http.Request;

/**
 * The <code>Action</code> object provides a service controller 
 * implementation for taking an action before delegating to other
 * service implementations, which will handle the view. It is 
 * used to implement controllers that ultimately redirect to
 * another service or site to complete the client request.
 * Typically the <code>execute</code> method is implemented
 * to perform some processing before being redirected.
 * </p>
 * The <code>lookup</code> and <code>resolve</code> methods are
 * used to acquire the desired resource object. This must then
 * be returned for the redirection to complete. If at any stage 
 * during processing and error occurs then an exception may be
 * thrown to the calling method to indicate the problem.
 *
 * @author Niall Gallagher
 */ 
public abstract class Action extends Controller {
   
   /**
    * Constructor for the <code>Action</code> object. This is 
    * used to create a service implementation that can be used 
    * as a controller. Any subclass of this can initialize 
    * itself using the <code>prepare</code> method.
    *
    * @param context the context this controller is rooted at
    */   	
   public Action(Context context){
      super(context);
   }
   
   /**
    * This <code>process</code> method is used to drive the 
    * <code>execute</code> method. This will simply invoke the
    * method and forward the client request to the resulting
    * <code>Resource</code> object, which completes the request.
    * 
    * @param req the HTTP request object representing the client
    * @param resp the HTTP response object to send a reply with
    * 
    * @throws Exception thrown if there is a problem processing  
    */    
   protected void process(Request req, Response resp) throws Exception{
      execute(req, resp).handle(req, resp);
   }
  
   /**
    * This method is used to retrieve services using the name 
    * for that service. This method delegates directly to the
    * <code>LoaderEngine.lookup</code> method implemented. This
    * method can be subclassed to provide a naming scheme, such
    * that resources can be acquired using aliases.
    *
    * @param target the target name referencing the resource
    *
    * @return the <code>Resource</code> that has been located
    */     
   public Resource lookup(String target) throws Exception {
      return engine.lookup(target);
   }

   /**
    * This method is used to retrieve services using the path
    * for that service. This method delegates directly to the
    * <code>LoaderEngine.resolve</code> method implemented. This
    * method can be subclassed to provide a mapping scheme, such
    * that resources can be acquired using pattern matches.
    *
    * @param target the target path referencing the resource
    *
    * @return the <code>Resource</code> that has been located
    */     
   public Resource resolve(String target) throws Exception {
      return engine.resolve(target);
   }

   /**
    * The <code>execute</code> method is used to perform various
    * operations before a request and response is forwarded. This 
    * is useful when no specific view is associated with a target
    * service or resource. It allows delegation to other resources,
    * which can then render the view for the HTTP transaction.
    * 
    * @param req the HTTP request object representing the client
    * @param resp the HTTP response object to send a reply with
    * 
    * @return returns the resource used to handle the request
    *  
    * @throws Exception thrown if there is a problem processing 
    */ 
   public abstract Resource execute(Request req, Response resp) throws Exception;
}
