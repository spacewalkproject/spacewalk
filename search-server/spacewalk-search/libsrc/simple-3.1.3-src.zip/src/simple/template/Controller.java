/*
 * Controller.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template;      
                        
import simple.http.load.Configuration;
import simple.http.load.LoadingException;
import simple.http.load.LoaderEngine;
import simple.http.load.Service;
import simple.http.serve.Context;

/**
 * The <code>Controller</code> object represents a service that can
 * access documents and properties provided by the templating system
 * environment. Each controller implementation will have access to
 * the documents via the <code>lookup</code> methods.
 *
 * @author Niall Gallagher
 *
 * @see simple.template.TemplateEngine
 */ 
public abstract class Controller extends Service {
        
   /**
    * Represents the environment the controller exists within.
    */
   protected Environment system;

   /**
    * This is the configuration object for this service object.
    */ 
   protected Configuration data;
   
   /**
    * Constructor for the <code>Controller</code> object. This will
    * create a controller using the provided context. A controller
    * is a typical service implementation, which is a resource.
    * 
    * @param context the context this controller is rooted at
    */    
   public Controller(Context context) {
      super(context);
   }
   
   /**
    * Initialize the controller with the environment used by the
    * templating engine. This can be overridden by a subclass to
    * perform some setup tasks for the service.
    *
    * @param system the environment used by the template engine
    * @param data this is the configuration for this service
    *
    * @throws LoadingException thrown if the preparation fails
    */   
   public void prepare(Configuration data, Environment system) throws LoadingException {
      try {
         prepare(data);                          
      } catch(Exception cause) {
         throw new LoadingException(cause);              
      }
      this.system = system;
      this.data = data;
   }

   /**
    * This can be overridden by a subclass to perform preparation
    * of the controller. It is generally recommended that this is
    * overridden so that the <code>Environment</code> is always
    * set for the subclass. This is provided for convinience.
    *
    * @param data this is the configuration for this service
    *
    * @throws Exception thrown if there is a preparation failure
    */ 
   public void prepare(Configuration data) throws Exception{
      this.data = data;           
   }
}
