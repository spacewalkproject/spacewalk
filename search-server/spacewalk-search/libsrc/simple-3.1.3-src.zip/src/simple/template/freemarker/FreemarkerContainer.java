/*
 * FreemarkerContainer.java January 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 */

package simple.template.freemarker;

import java.io.FileNotFoundException;
import freemarker.template.SimpleHash;
import freemarker.template.Configuration;
import simple.http.serve.CacheContext;
import simple.template.layout.Layout;
import simple.template.layout.Panel;
import simple.http.serve.Locator;
import simple.http.serve.Context;
import simple.template.Container;
import simple.template.Document;
import java.io.File;

/**
 * The <code>FreemarkerContainer</code> provides an implementation
 * of the <code>Container</code> object for <cite>Freemarker</cite>.
 * This can be used with a <code>TemplateEngine</code> to provide
 * template documents written in the Freemarker Templating Language
 * (FTL) to service objects. This container will use a template 
 * root that is the root of the <code>Context</code> specified.
 * <p>
 * A subclassed implementation of this <code>Container</code>
 * typically implements the <code>lookup(String)</code> method
 * inorder to populate a database with various tools or objects.
 * This can done by creating a <code>SimpleHash</code> instance 
 * and delegating to the <code>lookup(String,&nbsp;Object)</code>
 * method once the <code>SimpleHash</code> has been populated.
 *
 * @author Niall Gallagher
 *
 * @see freemarker.template.Configuration
 */
public class FreemarkerContainer extends FreemarkerDatabase implements Container {

   /**
    * Provides the engine used to create template objects.
    */
   private Configuration engine;
  
   /**
    * This is the context used for loading template documents.
    */ 
   private Context context;
   
   /**
    * Creates the document objects using the specified engine.
    */
   private Layout layout;  
   
   /**
    * Constructor for the <code>FreemarkerContainer</code> object.
    * The instance created will load templates from the current
    * working directory. So all URI paths provided, referencing
    * a template, will be resolved from the application path.
    *
    * @throws Exception if there is an initialization problem
    */
   public FreemarkerContainer() throws Exception{
      this(new CacheContext());
   }

   /**
    * Constructor for the <code>FreemarkerContainer</code> object.
    * The instance created will load templates from the context
    * path. So all URI paths provided will be resolved from the
    * root path of the provided context object.
    * 
    * @param context the context used to locate the templates
    *
    * @throws Exception if there is an initialization problem
    */
   public FreemarkerContainer(Context context) throws Exception{
      this(new Configuration(), context);
   }
   
   /**
    * Constructor for the <code>FreemarkerContainer</code> object.
    * If a specialized <code>Configuration</code> instance is
    * required one can be provided, this enables properties, such
    * as the template root and application attributes to be set.
    *
    * @param engine this is the engine used by this instance
    *
    * @throws Exception if there is an initialization problem
    */
   public FreemarkerContainer(Configuration engine) throws Exception{
      this(engine, new CacheContext());
   }

   /**
    * Constructor for the <code>FreemarkerContainer</code> object.
    * If a specialized <code>Configuration</code> instance is
    * required one can be provided, this enables properties, such
    * as the template root and application attributes to be set.
    *
    * @param engine this is the engine used by this instance
    * @param context the context used to locate the properties
    *
    * @throws Exception if there is an initialization problem
    */
   public FreemarkerContainer(Configuration engine, Context context) throws Exception{
      this.layout = new FreemarkerLayout(engine, context);
      this.data = new SimpleHash();
      this.context = context;
      this.engine = engine;
      this.init(context);
   }

   /**
    * In the event that the <code>Configuration</code> instance is
    * uninitialized this attempts to set the root path for loading 
    * of templates to the root context path. This will acquire the
    * base path of the context and set the template loading path
    * within the freemarker runtime. If the base directory does not
    * exist then this will throw a file not found exception.
    *
    * @param context the context used to locate the properties
    *
    * @throws Exception if there is a problem on initialization
    */
   protected void init(Context context) throws Exception {
      init(context.getBasePath());
   }

   /**
    * In the event that the <code>Configuration</code> instance is
    * uninitialized this attempts to set the root path for loading 
    * of templates to the specified path. All templates referenced
    * by this template will be resolved from the suggested path.
    *
    * @param root this is the directory used for loading templates
    *
    * @throws Exception if there is a problem on initialization
    */   
   protected void init(String root) throws Exception {
      init(new File(root));
   }      

   /**
    * In the event that the <code>Configuration</code> instance is
    * uninitialized this attempts to set the root path for loading 
    * of templates to the specified path. All templates referenced
    * by this template will be resolved from the suggested path.
    *
    * @param root this is the directory used for loading templates
    *
    * @throws Exception if there is a problem on initialization
    */    
   private void init(File root) throws Exception {
      try {           
         engine.setDirectoryForTemplateLoading(root);
      }catch(Exception e) {
         throw new FileNotFoundException(root.getName());
      }              
   }

   /**
    * Determines whether the named template exists. This is used
    * to determine if the <code>lookup</code> method will locate
    * a template given the specified path. If the template is
    * accessible this returns true, otherwise false is returned.
    *
    * @param path this is the path used to locate the template
    *
    * @return true if the template exists, false if it does not
    */
   public boolean exists(String path) {
      return context.getFile(path).exists();
   }

   /**
    * Looks for the named template and wraps the template within
    * a new <code>Document</code> instance. Resolving the location
    * of the template is left up the templating system, typically
    * this requires a file path reference to locate the template.
    * <p>
    * The document created by this method is transient, that is,
    * it is a unique instance. This means that changes to the
    * properties of any created document object affect only that
    * instance. By default this assumes the UTF-8 encoding.
    *
    * @param path this is the path used to locate the template
    *
    * @return the specified template wrapped within a document
    *
    * @throws Exception this is thrown if the is a problem with
    * locating or rendering the specified template
    */
   public Document lookup(String path) throws Exception {
      return lookup(path, true);
   }
   
   /**
    * Looks for the named template and wraps the template within
    * a new <code>Document</code> instance. Resolving the location
    * of the template is left up the templating system, typically
    * this requires a file path reference to locate the template.
    * <p>
    * The document created by this method is transient, that is,
    * it is a unique instance. This means that changes to the
    * properties of any created document object affect only that
    * instance. By default this assumes the UTF-8 encoding.
    *
    * @param path this is the path used to locate the template
    * @param share should the data model be shared or inherited
    *
    * @return the specified template wrapped within a document
    *
    * @throws Exception this is thrown if the is a problem with
    * locating or rendering the specified template
    */
   public Document lookup(String path, boolean share) throws Exception {
      return lookup(path, new Delegate(), share);           
   }

   /**
    * Looks for the named template and wraps the template within
    * a new <code>Document</code> instance. Resolving the location
    * of the template is left up the templating system, typically
    * this requires a file path reference to locate the template.
    * <p>
    * The document created by this method is transient, that is,
    * it is a unique instance. This means that changes to the
    * properties of any created document object affect only that
    * instance. By default this assumes the UTF-8 encoding.
    * <p>
    * This method allows the <code>SimpleHash</code> used by the
    * document object to be specified. This is useful if various
    * tools need to be added to the database before it is used by
    * the document, such as rendering tools and various others.
    *
    * @param path this is the path used to locate the template
    * @param data this provides a set of default properties
    *
    * @return the specified template wrapped within a document
    *
    * @throws Exception this is thrown if the is a problem with
    * locating or rendering the specified template
    */
   public Document lookup(String path, Object data, boolean share) throws Exception{
      return layout.getPanel(path, data, share);
   }

   /**
    * The <code>Delegate</code> object is used provide documents
    * with their own <code>SimpleHash</code>. This enables changes
    * made to the documents properties to be specific to that
    * instance. This will wrap this <code>Container</code>
    * database in such a way that it is used in a read only way.
    *
    * @see freemarker.template.SimpleHash
    */
   private class Delegate extends SimpleHash {

      /**
       * Constructor for the <code>Delegate</code> object. The
       * constructor delegates to the super class constructor
       * using the containers database as the inner database.
       * This prevent documents from changing that database.
       */
      public Delegate() throws Exception {
         putAll(data.toMap());
      }
   }
}
