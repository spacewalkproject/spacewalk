/*
 * FreemarkerVeiwerFactory.java May 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.freemarker;

import freemarker.template.SimpleHash;
import freemarker.template.TemplateModel;
import freemarker.template.TemplateModelException;
import simple.template.layout.ViewerFactory;
import simple.template.layout.Viewer;
import simple.http.serve.Context;

/**
 * The <code>FreemarkerVeiwerFactory</code> resolves a viewer
 * instance from a specified path. The location of the viewer
 * is relative to the user specified <cite>Freemarker</cite> 
 * template root. The viewers resolved by this factory object
 * wrap the template located at the specified path. In order 
 * to supply an initial set of data to a created viewer object 
 * a <code>SimpleHash</code> instance must be supplied.
 *
 * @author Niall Gallagher 
 */
final class FreemarkerViewerFactory implements ViewerFactory {
        
   /**
    * The engine used to acquire templates from a root path.
    */
   private FreemarkerLoader loader;

   /**
    * Constructor for the <code>FreemarkerVeiwerFactory</code>. This
    * creates a factory for creating viewer objects. The engine is
    * used to create and configure all referenced templates which
    * are then wrapped in a <code>Viewer</code> object.
    *
    * @param loader the loader used to acquire the templates 
    */
   public FreemarkerViewerFactory(FreemarkerLoader loader) {
      this.loader = loader;
   }

   /**      
    * Retrieves the referenced <code>Template</code> object from
    * the <cite>Freemarker</cite> runtime. This method is provided
    * for convenience, to avoid using <code>getTemplate</code> 
    * with the <code>Configuration</code> object. By default
    * this uses UTF-8 character encoding.
    *
    * @param path this is the path used to locate the template
    *
    * @throws FileNotFoundException if the template is not found
    */
   private FreemarkerTemplate getTemplate(String path) throws Exception {
      return loader.getTemplate(path);
   }
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the <cite>Freemarker</cite> runtime, which
    * acquires all resources from a user specified template root.
    * <p>
    * The viewer created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created viewer object affect only that 
    * instance. By default this assumes the UTF-8 encoding. 
    * <p>
    * To provide an initial set of properties to the viewer an
    * <code>Object</code> is used to populate the viewer. All
    * that is required to supply supplemental properties to the
    * viewer is to provide a populated <code>SimpleHash</code>.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared
    *
    * @throws FileNotFoundException if the template is not found
    */
   public Viewer getInstance(String path, Object data, boolean share) throws Exception {
      return getInstance(path, (SimpleHash)data, share);
   }
   
   /**
    * Creates a new <code>Viewer</code> object, which wraps the
    * referenced template. Resolving the location of the template 
    * to load is left up the <cite>Freemarker</cite> runtime, which
    * acquires all resources from a user specified template root.
    * <p>
    * The viewer created by this method is transient, that is,
    * it exists locally only. This means that changes to the 
    * properties of any created viewer object affect only that 
    * instance. By default this assumes the UTF-8 encoding. 
    * <p>
    * To provide an initial set of properties to the viewer a
    * <code>SimpleHash</code> is used to populate the viewer. All
    * that is required to supply supplemental properties to the
    * viewer is to provide a populated <code>SimpleHash</code>.
    * 
    * @param path this is the path used to locate the template
    * @param data the data source object to use for properties
    * @param share should the data model be inherited or shared
    *
    * @throws FileNotFoundException if the template is not found
    */
   private Viewer getInstance(String path, SimpleHash data, boolean share) throws Exception {
      return getInstance(getTemplate(path), data, share);
   }
   
   /**
    * This method will create a <code>Viewer</code> using the issued
    * <code>Template</code> object. The resulting viewer is populated
    * with data from the issued data source object. Changes to the 
    * properties of the viewer will be directly inserted into the 
    * issued <code>SimpleHash</code> instance if it is shared, if it
    * is not shared a new hash model which inherits the given model.
    * 
    * @param template the template object wrapped by the viewer
    * @param data this contains the initial set of properties 
    * @param share should the data model be inherited or shared 
    * 
    * @return an empty viewer that wraps the given template
    */
   private Viewer getInstance(FreemarkerTemplate template, SimpleHash data, boolean share) {
      return new FreemarkerViewer(template, share ? data : new ExtendedHash(data));
   }

   /**
    * This is a <code>SimpleHash</code> model, which can be used by 
    * a <cite>Freemarker</cite> template to establish a private data
    * model that can extends an existing data model. This ensures 
    * that changes to this data model do not affect the extended 
    * model. This allows tile layouts to be used with all templates.
    *
    * @see freemarker.template.SimpleHash
    */ 
   private class ExtendedHash extends SimpleHash {

      /**
       * This is the data model that has been extended by this.
       */            
      private SimpleHash root;           

      /**
       * Constructor for the <code>ExtendedHash</code> object. This
       * will make use of the provided hash model to get inherited
       * properties. This acts as a fallback model for the template.
       *
       * @param root the data model providing inherited properties
       */ 
      public ExtendedHash(SimpleHash root) {
         this.root = root;              
      }           

      /**
       * This will search for the property using the provided key. 
       * The data will be searched for firstly using the private data
       * of this instance, failing that the extended data model. This
       * ensures the extended model properties are available to the
       * template and prevents changes from affecting that model.  
       *
       * @param key this is the key used to reference the property
       *
       * @return this returns a template model representing the value
       */ 
      public TemplateModel get(String key) throws TemplateModelException {
         TemplateModel data = super.get(key);

         if(data == null) {
            return root.get(key);
         }         
         return data;
      }              
   }
}
