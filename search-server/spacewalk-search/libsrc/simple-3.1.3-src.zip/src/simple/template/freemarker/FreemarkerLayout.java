/*
 * FreemarkerVeiwerFactory.java December 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.template.freemarker;

import freemarker.template.Configuration;
import simple.template.layout.ViewerFactory;
import simple.template.layout.LayoutFactory;
import simple.template.layout.Layout;
import simple.template.layout.Panel;
import simple.http.serve.Context;

/**
 * The <code>FreemarkerLayout</code> object provides an implementation
 * of the <code>Layout</code> interface for <cite>Freemarker</cite>.
 * This acts a a convinience object that avoids having to deal
 * with the <code>LayoutFactory</code>. Internally this delegates
 * to an instance retrieved from the factory.
 * 
 * @author Niall Gallagher
 */ 
final class FreemarkerLayout implements Layout {

   /**
    * The <code>Layout</code> used internally by this instance.
    */ 
   private Layout layout;
   
   /**
    * Constructor for the <code>FreemarkerLayout</code> object. This
    * uses the provided <code>Configuration</code> to interface
    * with the <cite>Freemarker</code> templating system and each of
    * the documents produced will be rendered by that system.
    *
    * @param engine interfaces with the templating system used
    * @param context this is used to provide the configuration
    */ 
   public FreemarkerLayout(Configuration engine, Context context){
      this(new FreemarkerLoader(engine, context), context);
   }
   
   /**
    * Constructor for the <code>FreemarkerLayout</code> object. This
    * uses the provided <code>Configuration</code> to interface
    * with the <cite>Freemarker</code> templating system and each of
    * the documents produced will be rendered by that system.
    *
    * @param loader interfaces with the templating system used
    * @param context this is used to provide the configuration
    */ 
   public FreemarkerLayout(FreemarkerLoader loader, Context context){
      this(new FreemarkerViewerFactory(loader), context);
   }
   
   /**
    * Constructor for the <code>FreemarkerLayout</code> object. This
    * uses the provided <code>ViewerFactory</code> to interface
    * with the <cite>Freemarker</code> templating system and each of
    * the documents produced will be rendered by that system.
    * 
    * @param factory interfaces with the templating system used
    * @param context this is used to provide the configuration
    */ 
   public FreemarkerLayout(ViewerFactory factory, Context context){
      this.layout = LayoutFactory.getInstance(factory, context);
   }
   
   /**
    * This method is used to delegate directly to the internal
    * <code>Layout</code>. Because this is used as a convinience
    * object it does not provide any direct functionality, so
    * this essentially acts as a wrapper for the internal object.
    *
    * @param name this is the target template or layout to use
    * @param data this is the data source used by the template
    * @param share should the data model be inherited or shared
    */
   public Panel getPanel(String name, Object data, boolean share) throws Exception{
      return layout.getPanel(name, data, share);           
   }
}
