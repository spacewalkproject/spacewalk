/*
 * FreemarkerLoader.java January 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 */

package simple.template.freemarker;

import freemarker.template.Template;
import freemarker.template.Configuration;
import simple.http.serve.Context;

/**
 * The <code>FreemarkerLoader</code> intefaces with the Freemarker
 * templating system. This is used to load velocity templates which 
 * have a default character encoding of UTF-8 and the type resolved
 * from the <code>Context</code> object.
 *
 * @author Niall Gallagher
 */ 
final class FreemarkerLoader {

   /**
    * This is the interface to the Freemarker templating system.
    */         
   private Configuration engine;

   /**
    * This is used to resolve the MIME type for the template.
    */    
   private Context context;   

   /**
    * Constructor for the <code>FreemarkerLoader</code> object. This is
    * used to wrap the provide Freemarker engine and provide templates,
    * with a default UTF-8 character encoding and a suitable MIME type.
    *
    * @param engine this is the interface to the templating system
    * @param context this is used to resolve the MIME types
    */ 
   public FreemarkerLoader(Configuration engine, Context context){
      this.context = context;
      this.engine = engine;      
   }

   /**
    * This acquires a Freemarker template from the Freemarker templating
    * system. This uses the URI path provided to load the template
    * from the configured root for templates. The templates loaded
    * will use the UTF-8 character encoding.
    *
    * @param path this is the path to load the template from
    */ 
   public FreemarkerTemplate getTemplate(String path) throws Exception{
      return getTemplate(path, getContentType(path));
   }

   /**
    * This acquires a Freemarker template from the Freemarker templating
    * system. This uses the URI path provided to load the template
    * from the configured root for templates. The templates loaded
    * will use the UTF-8 character encoding.
    *
    * @param path this is the path to load the template from
    * @param type this is the MIME type for the loaded template
    */     
   public FreemarkerTemplate getTemplate(String path, String type) throws Exception{
      return getTemplate(engine.getTemplate(path), type);
   }     

   /**
    * This wraps the loaded template in a container, which exposes
    * the content type and character encoding used. The template 
    * allows the <code>Viewer</code> to satisfy its interface methods.
    * 
    * @param template template this is the template to be wrapped
    * @param type this is the MIME type for the loaded template
    */ 
   public FreemarkerTemplate getTemplate(Template template, String type) throws Exception{     
      return new FreemarkerTemplate(template, type);           
   }
   
   /**
    * This delegates to the <code>Context</code> object, to resolve
    * the MIME type for the template. By default this makes use if
    * the template path and file extension to resolve the type.
    * 
    * @return this returns the MIME type matching the path
    */ 
   private String getContentType(String path) {
      return context.getContentType(path);               
   }
}
