/*
 * Page.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page;

import java.io.PrintWriter;

/**
 * The <code>Page</code> object is used to define the interface to a 
 * compile page object. This contract must be fulfilled by all pages
 * compiled by the server. If the content type is specified within
 * the JSP source then the content type and charset will be set.
 * 
 * @author Niall Gallagher
 *
 * @see simple.page.BasicPage
 */ 
public interface Page {

   /**
    * This is used to write the contents of the JSP page to the writer
    * provided. This method is implemented by the translator from
    * the text and code provided by the JSP. The model contains all 
    * data passed from the HTTP service to the page.
    *
    * @param out this is the writer used to output the page contents
    * @param model this contains all attributes passed into the page
    */ 
   public void write(PrintWriter out, Model model) throws Exception;        

   /**
    * This is used to provide a MIME content type, which can be used
    * by the HTTP service to the the Content-Type header. This will
    * allow the JSP to determine how the pages is presented.
    *
    * @return this returns the MIME type and charset for the page
    */ 
   public String getContentType();

   /**
    * This is used to provide the character encoding that will be used
    * when the page is marshalled to a byte stream. Typically this
    * will be UTF-8 however it can be overridden by the JSP source.
    *
    * @return this returns the chatacter encoding for the page
    */  
   public String getCharset();
}
