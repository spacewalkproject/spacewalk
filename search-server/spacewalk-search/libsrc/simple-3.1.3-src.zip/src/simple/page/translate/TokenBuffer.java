/*
 * TokenBuffer.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.translate;

import simple.util.parse.ParseBuffer;

/**
 * The <code>TokenBuffer</code> represents an object used to collect
 * characters from an implementation of a <code>Token</code>. The
 * primary goal with the token buffer is to allow fast a collection
 * of characters and a simple conversion of those characters to a 
 * string object.
 *
 * @author Niall Gallagher
 *
 * @see simple.page.translate.Token
 */ 
class TokenBuffer extends ParseBuffer { 

   /**
    * This will convert the accumulated characters to a string that
    * represents a token. If no characters were collected by this
    * instance then a zero length string is returned from this.
    *
    * @return this returns a string representing the token
    */       
   public String text() {
      return new String(buf, 0, count);           
   }        
}
