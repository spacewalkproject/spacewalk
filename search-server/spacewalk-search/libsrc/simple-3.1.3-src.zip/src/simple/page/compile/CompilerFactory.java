/*
 * CompilerFactory.java March 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.compile;

import java.lang.reflect.Constructor;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import simple.page.translate.Source;
import simple.page.Workspace;

/**
 * The <code>CompilerFactory</code> is used to compile a translated JSP
 * source file. This compiler is capable of compiling any source type,
 * as long as there is an implementation supporting the language. By
 * default there are two supported languages, Java and Groovy. If no
 * runtime language is specified Java is assumed. 
 * 
 * @author Niall Gallagher 
 */ 
final class CompilerFactory {

   /**
    * Represents the registry for all supported runtime languages.
    */ 
   private static ResourceBundle load;   
   
   static {      
      try { 
         load = ResourceBundle.getBundle("simple.page.compile.Compiler");
      }catch(MissingResourceException e){
         e.printStackTrace();
      }   
   }
        
   /**
    * Represents the workspace the compiler should build within.
    */    
   private Workspace project;        

   /**
    * Constructor for the <code>CompilerFactory</code> object. This is 
    * used to create compilers for the specified workspace. This will
    * create compilers from those named in the Compiler properties.
    * 
    * @param project this is the project to create compilers for
    */ 
   public CompilerFactory(Workspace project) {
      this.project = project;           
   }        

   /**
    * This is used to create a <code>Compiler</code> instance for the
    * language requested by the provided source file. By default the
    * only languages supported are Java and Groovy. If no language is
    * specified then Java is assumed.
    *
    * @param source this is the source file specifying the language
    *
    * @return this is the compiler capable of compiling the source
    */
   public Compiler getInstance(Source source) throws Exception {
      String type = source.getLanguage();
      try {
         type = load.getString(type);                  
      }catch(MissingResourceException e){
         return new JavaCompiler(project);
      }            
      return getInstance(type);
   }

   /**
    * This is used to create a <code>Compiler</code> instance for the
    * class specified. This will attempt to load the class for the
    * compiler from this class class loader. If the class cannot be
    * loaded then this will use the <code>JavaCompiler</code> object.
    *
    * @param className this is the fully qualified compiler name
    *
    * @return this is the compiler capable of compiling the source
    */
   private Compiler getInstance(String className) throws Exception {
      try {           
         Constructor factory = getConstructor(className);
         return (Compiler)factory.newInstance(
                  new Object[]{project}); 
      }catch(Exception e) {
         return new JavaCompiler(project);
      }
   }

   /**
    * Here a <code>ClassLoader</code> is selected to load the class.
    * This will load the class specified using this classes class
    * loader. If there are no problems in loading the class then a
    * <code>Constructor</code> is created from the loaded class.
    *    
    * @param className this is the name of the class to load
    */ 
   private Constructor getConstructor(String className) throws Exception {
      return getConstructor(Class.forName(className,
         false, CompilerFactory.class.getClassLoader()));           
   }
   
   /**
    * Creates the <code>Constructor</code> for the implementation
    * so that an instance can be created. This will use the class
    * which has been previously loaded to acquire the constructor.
    * The constructor object acquired is for a single argument
    * constructor that takes a <code>Workspace</code> object.
    *
    * @param type this is the implementation class to be used
    *
    * @return this returns a constructor for the specified class
    */   
   private Constructor getConstructor(Class type) throws Exception {
      Class[] list = new Class[]{Workspace.class};           
      return type.getDeclaredConstructor(list);
   }  
   
}
