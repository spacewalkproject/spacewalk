/*
 * Compiler.java March 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.compile;

import org.apache.tools.ant.types.Path;
import simple.page.translate.Source;
import simple.page.Workspace;
import java.io.IOException;
import java.io.File;

/**
 * The <code>Compiler</code> object is used to compile a translated
 * source. This is provided the source specification for the page, 
 * which contains the class name, the runtime language, and location.
 * This should be subclassed to support a specific language, the 
 * current languages supported are Java and Groovy.
 * 
 * @author Niall Gallagher
 *
 * @see simple.page.compile.GroovyCompiler
 * @see simple.page.compile.JavaCompiler
 */ 
public class Compiler {

   /**
    * This is used to create a compiler for the specified source.
    */         
   protected CompilerFactory factory;        

   /**
    * This is used to load the class files from the workspace.
    */  
   protected CompilerLoader loader;

   /**
    * This is the build directory for the provided workspace.
    */ 
   protected File root;
        
   /**
    * Constructor for the <code>Compiler</code> object. This is used 
    * to create a compiler that compiles classes into the workspace
    * build directory. This will delegate the compilation process to
    * a subclass implementation, which can handle a specific language.
    *
    * @param project this is the project that defines the layout
    */ 
   public Compiler(Workspace project) throws IOException {
      this(project, project.getBuildPath());
   }

   /**
    * Constructor for the <code>Compiler</code> object. This is used 
    * to create a compiler that compiles classes into the workspace
    * build directory. This will delegate the compilation process to
    * a subclass implementation, which can handle a specific language.
    *
    * @param project this is the project that defines the layout
    * @param root this is the build directory for the workspace
    */    
   private Compiler(Workspace project, File root) throws IOException {
      this.factory = new CompilerFactory(project);
      this.loader = new CompilerLoader(project);
      this.root = root;
   }        

   /**
    * This is used to load the compiled class from the project build
    * directory. If the JSP has not been translated and compiled 
    * this will throw an exception. If however, the source JSP was 
    * previously translated and compiled this will return the class.
    *
    * @param source this contains the details need to load the class
    *
    * @return returns the class definition for the compiled class
    */ 
   public synchronized Class load(Source source) throws Exception {
      return loader.load(source);           
   }
   
   /**
    * This will compile an load the specified source specificaiton.
    * The provided <code>Source</code> object must contain the class
    * name, the source location and the runtime language to be used.
    * This method will delegate the compilation procedure to a class
    * that implements this method for a specific language type.
    *
    * @param source this contains the details for the source file
    *
    * @return returns the class definition for the compiled class
    */         
   public synchronized Class compile(Source source) throws Exception {
      return compile(source, null);           
   }

   /**
    * This will compile an load the specified source specificaiton.
    * The provided <code>Source</code> object must contain the class
    * name, the source location and the runtime language to be used.
    * This method will delegate the compilation procedure to a class
    * that implements this method for a specific language type.
    *
    * @param source this contains the details for the source file
    * @param path this is the full classpath for the compiler
    *
    * @return returns the class definition for the compiled class
    */    
   public synchronized Class compile(Source source, Path path) throws Exception {
      Compiler compiler = factory.getInstance(source);

      if(compiler != null) {
         return compiler.compile(source, path);              
      }      
      return null;
   }
}







