/*
 * JavaCompiler.java March 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.compile;

import org.apache.tools.ant.taskdefs.Javac;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.Project;
import simple.page.translate.Source;
import simple.page.Workspace;
import java.io.File;

/**
 * The <code>JavaCompiler</code> is used to compile the java sources
 * within the workspace build path. This delegates the compilation to
 * the Ant <code>Javac</code> task definition. This allows the Java
 * source to be compiled in a consistant manner. One requirement for
 * the use of this compiler is that the "tools.jar" JAR file is 
 * within the classpath. Typically this JAR is found within the path 
 * "$JAVA_HOME/lib/tools.jar".
 * 
 * @author Niall Gallagher
 */ 
final class JavaCompiler extends Compiler {

   /**
    * Constructor for the <code>JavaCompiler</code> object. This is 
    * used to create a compiler implementation that can compile Java
    * source files within the workspace build path.
    *
    * @param project this is the workspace to be used for compilation
    */ 
   public JavaCompiler(Workspace project) throws Exception{
      super(project);
   }

   /**
    * This method is used to perform the actual compilation of the 
    * source files within the workspace build path. This makes use of
    * the Ant <code>Javac</code> task definition to compile the Java
    * source files, all sources within the build path are compiled.
    *
    * @param source the source file to be compiled and loaded
    *
    * @return this is the class definition compiled and loaded
    */ 
   public Class compile(Source source) throws Exception {
      return compile(source, null);
   }

   /**
    * This method is used to perform the actual compilation of the 
    * source files within the workspace build path. This makes use of
    * the Ant <code>Javac</code> task definition to compile the Java
    * source files, all sources within the build path are compiled.
    *
    * @param source the source file to be compiled and loaded
    * @param path this is the full class path for the Java compiler
    *
    * @return this is the class definition compiled and loaded
    */ 
   public Class compile(Source source, Path path) throws Exception {
      Project project = new Project();           
      Javac compiler = new Javac();

      project.init();      
      compiler.setProject(project);
      compiler.createSrc().setLocation(root);
      compiler.setClasspath(path);
      compiler.setDebug(true);
      compiler.execute();           
      
      return load(source);
   }   
}







