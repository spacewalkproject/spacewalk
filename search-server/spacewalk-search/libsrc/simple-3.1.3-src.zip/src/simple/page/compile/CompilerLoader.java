/*
 * CompilerLoader.java March 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.compile;

import simple.page.translate.Source;
import simple.page.Workspace;
import java.net.URLClassLoader;
import java.io.IOException;
import java.net.URL;
import java.io.File;

/**
 * The <code>CompilerLoader</code> is used to load class files that
 * have been recently compiled. This will look for all class files from
 * within the build path, typically, WEB-INF. This loader is required
 * by the compilation framework to ensure that newly compile JSPs are
 * reachable via a class loader, and also reloadable on modification. 
 *
 * @author Niall Gallagher
 */ 
final class CompilerLoader {
 
   /**
    * Represents the project workspace used for compiling sources.
    */           
   private Workspace project;

   /**
    * Represents a class loader used to cache system scoped classes.
    */ 
   private ClassLoader loader;        

   /**
    * Represents the build path used to load JSP class files.
    */ 
   private URL[] codebase;

   /**
    * Constructor for the <code>CompilerLoader</code> object. This is
    * used to create a class loading facility for the compilation
    * framework. This will load classes from the workspace build path.
    *
    * @param project this is the workspace used by the compiler
    */ 
   public CompilerLoader(Workspace project) throws IOException {
      this(project, project.getBuildPath());           
   }

   /**
    * Constructor for the <code>CompilerLoader</code> object. This is
    * used to create a class loading facility for the compilation
    * framework. This will load classes from the workspace build path.
    *
    * @param project this is the workspace used by the compiler
    * @param base this is the workspace build path for this loader
    */ 
   private CompilerLoader(Workspace project, File base) throws IOException {
      this.loader = CompilerLoader.class.getClassLoader();
      this.codebase = new URL[] {base.toURL()};
      this.project = project;
   }       

   /**
    * This is used to load the compiled class from the workspace build
    * path. This uses the source object created by the translation
    * process to acquire the fully qualified class name for the JSP.
    *
    * @param source this contains the class name form the JSP object
    *
    * @return this returns a class representing the compiled JSP
    */ 
   public Class load(Source source) throws Exception{
      String type = source.getTarget();

      try {
         return getClassLoader().loadClass(type);
      }catch(Exception e) {
         return loader.loadClass(type);              
      }         
   }

   /**
    * This is used to acquire a new class loader for loading the JSP
    * class. A new class loader is required each time to ensure that if
    * the JSP class was modified it is not cached within a static 
    * class loader. This delegates to the system class loader.
    *
    * @return this returns a clean class loader to load the JSP class
    */ 
   private ClassLoader getClassLoader() throws Exception {
      return getClassLoader(loader);
   }

   /**
    * This is used to acquire a new class loader for loading the JSP
    * class. A new class loader is required each time to ensure that if
    * the JSP class was modified it is not cached within a static 
    * class loader. This delegates to the system class loader.
    *
    * @param parent this is the parent class loader to delegate to 
    * 
    * @return this returns a clean class loader to load the JSP class
    */ 
   private ClassLoader getClassLoader(ClassLoader parent) throws Exception {
      return new URLClassLoader(codebase, parent);   
   }
}

