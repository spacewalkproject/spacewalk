/*
 * GroovyCompiler.java March 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.compile;

import org.codehaus.groovy.ant.Groovyc;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.Project;
import simple.page.translate.Source;
import simple.page.Workspace;
import java.io.File;

/**
 * The <code>GroovyCompiler</code> is used to compile Groovy sources 
 * from within the workspace build path. This will attempt to locate all
 * files ending with the file extension ".groovy". This can be used in
 * conjunction with the Java compilation task as it will ignore Java
 * source files. This will compile all sources within the build path.
 * 
 * @author Niall Gallagher
 */ 
final class GroovyCompiler extends Compiler {

   /**
    * Constructor for the <code>GroovyCompiler</code> object. This is 
    * used to create a compiler implementation that can compile Groovy
    * source files within the workspace build path.
    *
    * @param project this is the workspace to be used for compilation
    */    
   public GroovyCompiler(Workspace project) throws Exception{
      super(project);
   }

   /**
    * This method is used to perform the actual compilation of the 
    * source files within the workspace build path. This makes use of
    * the Ant <code>Groovyc</code> task definition to compile Groovy
    * source files, all sources within the build path are compiled.
    *
    * @param source the source file to be compiled and loaded
    *
    * @return this is the class definition compiled and loaded
    */    
   public Class compile(Source source) throws Exception {
      return compile(source, null);
   }
   
   /**
    * This method is used to perform the actual compilation of the 
    * source files within the workspace build path. This makes use of
    * the Ant <code>Groovyc</code> task definition to compile Groovy
    * source files, all sources within the build path are compiled.
    *
    * @param source the source file to be compiled and loaded
    * @param path this is the full class path for the Groovy compiler
    *
    * @return this is the class definition compiled and loaded
    */ 
   public Class compile(Source source, Path path) throws Exception {
      Project project = new Project();           
      Groovyc compiler = new Groovyc();
      String base = root.getAbsolutePath();
      
      project.init();      
      compiler.setProject(project);
      compiler.setSrcdir(new Path(project, base));
      compiler.setDestdir(project.resolveFile(base));
      compiler.setClasspath(path);
      compiler.execute();
      
      return load(source);
   }
   
}







