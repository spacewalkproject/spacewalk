/*
 * CompileTask.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.ant;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import java.io.File;

/**
 * The <code>CompileTask</code> represents an Ant task definition that
 * can be used within an Ant build file to compile JSP templates. This
 * offers the ability to use pre-compiled JSP templates with the 
 * template engine. Compiling the templates before starting the server
 * ensures that an initial delay on requesting a page is not incurred.
 * To add this task to your Ant build the following can be used.
 * <pre>
 * 
 * &lt;taskdef name="jspc" classname="simple.page.ant.CompileTask"/&gt;
 * 
 * </pre>
 * This declares a task named "jspc" which can be used within the Ant
 * build.xml file to compile JSP sources. Typically you will have to 
 * add a classpath to the taskdef declaration so that it knows where
 * to load the <code>CompileTask</code> byte code. 
 * <p>
 * Once the task definition has been declared you will need to create
 * a task execution configuration block. The following is an example 
 * of how to write a JSP compilation task. In the configuration below
 * the "build" parameter is where sources and classes will be compiled
 * to. The "project" parameter specifies the root package name used.
 * <pre>
 * 
 *    &lt;jspc build="${home}/WEB-INF" project="test"&gt;
 *       &lt;source dir="${home}"&gt;
 *          &lt;include name="**&#47;*.jsp"/&gt;
 *       &lt;/source&gt;
 *       &lt;classpath&gt;
 *          &lt;fileset dir="${lib}"&gt;
 *             &lt;include name="**&#47;*.jar"/&gt;
 *       &lt;/fileset&gt;
 *       &lt;/classpath&gt;
 *    &lt;/jspc&gt;
 *
 * </pre>
 * To ensure that your JSP sources compile, you will need to add a
 * classpath to the compiler. The classpath used has the same format
 * of a typical Ant classpath element. Finally, the source element is
 * used to specify the directory the source files are read from as 
 * well as the source files to include, this is an Ant "fileset".
 * 
 * @author Niall Gallagher
 */ 
public class CompileTask extends Task {
 
   /**
    * This contains the configuration used for the source files.
    */         
   private SourceSet source;

   /**
    * This is the full classpath to use to compile the sources.
    */ 
   private Path classpath;
    
   /**
    * This is the name of the project, it acts as the root package.
    */ 
   private String project;
    
   /**
    * This is the file system directory to compile sources to.
    */  
   private File build;
   
   /**
    * This is used to set the classpath from an attribute. This will
    * either complement the classpath element used in the compile 
    * block or act as the sole classpath used to compile the sources.
    *
    * @param path this is the classpath specified in the Ant task
    */  
   public void setClasspath(Path path) {
      if(classpath == null) {
         classpath = path;
      } else {
         classpath.append(path);
      }
   }

   /**
    * This is used to set the configuration for the source files to
    * build. This is an Ant "fileset" and contains a directory as
    * well as a collection of included and excluded sources. This is
    * typically given a pattern such as "*.jsp" to match JSP files.
    *
    * @param source this is the file set for matching JSP sources
    */ 
   public void addSource(FileSet source) throws BuildException {
      this.source = new SourceSet(source);
   }    
  
   /**
    * This is used to create a classpath element from the Ant task.
    * This is used if there are multiple JAR files to be used in the
    * classpath or if a simple classpath attribute is not sufficient.
    * 
    * @return this returns a path, which will be given the classpath
    */   
   public Path createClasspath() {
      Project project = getProject();
      
      if(classpath == null) {
         classpath = new Path(project);
      }
      return classpath.createPath();
   }
    
   /**
    * This is used to collect the build directory, which is where 
    * the JSP source files are translated and compiled to. This is
    * typically a WEB-INF directory within the source directory.
    * 
    * @param build this is the directory to compile JSP sources to
    */ 
   public void setBuild(File build) {
      this.build = build;
   }

   /**
    * This is used to specify the name of the JSP workspace. This is
    * used by the workspace to set a root package name for all of
    * the translated and compiled sources. This is useful when there
    * are multiple sources compiled into the same build directory.
    *
    * @param project this is the root package for the sources
    */ 
   public void setProject(String project) {
      this.project = project;
   }

   /**
    * This is used to execute the compile step. This will locate all
    * the sources specified within the source element and transform
    * them to URI paths, so that the cam be used by the translation
    * and compilation tools for the JSP template framework.
    *
    * @exception BuildException if there is a problem compiling
    */ 
   public void execute() throws BuildException {
      try {           
         String[] list = source.getSources();
         File path = source.getPath();
              
         execute(path, list);
      }catch(Exception e) {
         throw new BuildException(e);              
      }   
   }

   /**
    * This is used to execute the compile step. This will locate all
    * the sources specified within the source element and transform
    * them to URI paths, so that the cam be used by the translation
    * and compilation tools for the JSP template framework.
    *
    * @param path this is the path to locate the JSP sources from 
    * @param list this is a list of URI paths for the JSP targets
    *
    * @exception Exception if there is a problem compiling sources
    */ 
   public void execute(File path, String[] list) throws Exception {      
      new CompileSource(path, build, 
            project).compile(list, classpath);
   }   
}















