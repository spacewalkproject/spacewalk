/*
 * CompileSource.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.ant;

import org.apache.tools.ant.types.Path;
import simple.page.translate.Translator;
import simple.page.translate.Source;
import simple.page.compile.Compiler;
import simple.http.serve.FileContext;
import simple.http.serve.Context;
import simple.page.Workspace;
import java.io.File;

/**
 * The <code>CompileSource</code> this is used to perform the JSP
 * translation and compilation. This will initially translate all of
 * the source files requested. Once the source files have been 
 * translated each is compiled and loaded to ensure it will operate
 * correctly when used by the <code>Composer</code> object. This is
 * called from the Ant task to perform the job of compilation.
 * 
 * @author Niall Gallagher
 */ 
final class CompileSource {

   /**
    * This is the translator used for the JSP workspace created.
    */ 
   private Translator translator;

   /**
    * This is the compiler used for the JSP workspace created.
    */ 
   private Compiler compiler;

   /**
    * This is the workspace used by this to compile the sources.
    */ 
   private Workspace project;

   /**
    * Constructor for the <code>CompileSource</code> object. This is
    * used to create an object, that can be used to compile a set of
    * URI path targets relative to a source base directory. The name
    * provided represents the root package name for all sources.
    *
    * @param source this is the source directory where JSP files are
    * @param build this is where all JSP sources are translated to
    * @param name this is the root package name used by sources
    */       
   public CompileSource(File source, File build, String name) throws Exception {
      this(new FileContext(source), build, name);           
   }

   /**
    * Constructor for the <code>CompileSource</code> object. This is
    * used to create an object, that can be used to compile a set of
    * URI path targets relative to a source context path. The name
    * provided represents the root package name for all sources.
    *
    * @param source this is the source context where JSP files are
    * @param build this is where all JSP sources are translated to
    * @param name this is the root package name used by sources
    */      
   public CompileSource(Context context, File build, String name) throws Exception {
      this.project = new Workspace(context, name, build);
      this.translator = new Translator(project);
      this.compiler = new Compiler(project);  
   }

   /**
    * This is used to compile the specified sources using the given
    * class path. The classpath provided is taken from the driving
    * Ant task, it represents the classpath required to compile the
    * JSP source files. This path can be optionally empty.
    *
    * @param list this is the list of URI path targets to compile
    * @param path this is the classpath used to compile sources
    */ 
   public void compile(String[] list, Path path) throws Exception {
      Source[] source = translate(list);
      
      for(int i = 0; i < source.length; i++) {
         compile(source[i], path);     
      }             
   }   
   
   /**
    * This is used to compile the specified source using the given
    * classpath. The classpath provided is taken from the driving
    * Ant task, it represents the classpath required to compile the
    * JSP source files. This path can be optionally empty.
    *
    * @param list this is the translated JSP source object
    * @param path this is the classpath used to compile sources
    */ 
   private void compile(Source source, Path path) throws Exception{
      try {
         compiler.load(source);
      }catch(Exception e) {
         compiler.compile(source, path);           
      }         
   }   
   
   /**
    * This method is used to translate the list of URI paths. The
    * paths provided will represent JSP files within the workspace
    * source directory. If there is a problem translating any of
    * the sources this will throw an exception and the build fails.
    *
    * @param list this is the list of URI path targets to translate
    * 
    * @return this is the list of translated JSP source objects
    */ 
   private Source[] translate(String[] list) throws Exception {
      Source[] done = new Source[list.length];
      
      for(int i = 0; i < list.length; i++) {
         done[i] = translator.translate(list[i]);
      }           
      return done;
   }
}
