/*
 * SourceSet.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page.ant;

import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.types.FileSet; 
import org.apache.tools.ant.Project;
import java.io.File;

/**
 * The <code>SourceSet</code> object is used for collecting information
 * regarding the JSP sources to compile. This is a typical Ant file
 * set, and it requires a directory as well as a collection of pattern
 * matches to either include or exclude sources. For example take the
 * definition for the source element shown below.
 * <pre>
 * 
 *    &lt;source dir="${home}"&gt;
 *       &lt;include name="**&#47;*.jsp"/&gt;
 *       &lt;exclude name="include&#47;*.jsp"/&gt;
 *    &lt;/source&gt; 
 *    
 * </pre>
 * The above definition will include all files ending in "*.jsp" in
 * the "${home}" directory, except within the "include" directory.
 * As many path elements, include patterns, and exclude patterns can
 * be used within the source element.
 * 
 * @author Niall Gallagher
 */ 
final class SourceSet {

   /**
    * This is the file set used to collect the JSP source files.
    */         
   private FileSet set;

   /**
    * Constructor for the <code>SourceSet</code> object. This is the
    * constructor used by the Ant framework to reflectively create
    * a source set object to populate with file matching patterns.
    */         
   public SourceSet(FileSet set) {
      this.set = set;
   }        

   /**
    * This is the directory specified within the source element. If
    * a source element did not contain a directory then this provides
    * the current working directory, ".", otherwise the specified one.
    *
    * @return this returns the directory within the "dir" attribute
    */ 
   public File getPath() {
      Project project = set.getProject();
      File path = set.getDir(project);

      if(path == null) {
         return new File(".");                       
      }
      return path;
   }

   /**
    * This method is used to collect the URI path targets that matched
    * the patterns set in the Ant task. This ensures that regardless 
    * of the host file system the paths matched are converted into a
    * relative URI style path that can be used by the JSP engine.
    *
    * @return this returns a list of the paths matched as URI paths
    */ 
   public String[] getSources() {
      Project project = set.getProject();

      if(project == null) {
         return new String[]{};              
      }
      return getSources(project);      
   }

   /**
    * This method is used to collect the URI path targets that matched
    * the patterns set in the Ant task. This ensures that regardless 
    * of the host file system the paths matched are converted into a
    * relative URI style path that can be used by the JSP engine.
    *
    * @param project this is the project used to scan for sources
    * 
    * @return this returns a list of the paths matched as URI paths
    */ 
   private String[] getSources(Project project) {
      DirectoryScanner path = set.getDirectoryScanner(project);
      path.scan();
      return getSources(path);
      
   }

   /**
    * This method is used to collect the URI path targets that matched
    * the patterns set in the Ant task. This ensures that regardless 
    * of the host file system the paths matched are converted into a
    * relative URI style path that can be used by the JSP engine.
    *
    * @param path this is the scanner used to locate the JSP sources
    * 
    * @return this returns a list of the paths matched as URI paths
    */ 
   private String[] getSources(DirectoryScanner path) {
      String[] list = path.getIncludedFiles();
      
      for(int i = 0; i < list.length; i++) {
         if(!list[i].startsWith("/")) {
            list[i] = "/" + list[i];                 
         }              
         list[i] = list[i].replace(File.separatorChar, '/');
      }
      return list;
   }
}
