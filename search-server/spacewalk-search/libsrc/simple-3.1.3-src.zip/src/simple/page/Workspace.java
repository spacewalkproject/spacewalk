/*
 * Workspace.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page;

import simple.http.serve.FileContext;
import simple.http.serve.Context;
import simple.http.serve.Locator;
import simple.util.net.Path;
import java.io.IOException;
import java.io.File;

/**
 * The <code>Workspace</code> object is used to specify the source and
 * build context for the JSP translation and compilation process. This
 * allows the source files, that is, the JSP sources, and build files
 * to be acquired by the JSP engine. The build files, are the Java or
 * Groovy sources, and the class files compiled. Typically these will
 * be located within a WEB-INF directory in the source root, however,
 * the workspace can be configured to use any directory.
 * 
 * @author Niall Gallagher
 */ 
public class Workspace {

   /**
    * Specifies the default build directory for sources and classes.
    */ 
   private static final String DEFAULT_BASE = "/WEB-INF";        

   /**
    * Acquires the JSP source context for the workspace instance.
    */ 
   private Context source;
   
   /**
    * Acquires the build file context for the workspace instance.
    */ 
   private Context build;

   /**
    * This is the name of this JSP project workspace instance.
    */ 
   private String name;
   
   /**
    * The is the build context base, which is typically WEB-INF.
    */ 
   private File base;
  
   /**
    * Constructor for the <code>Workspace</code> object. This uses a
    * JSP context root to create a default configuration. With this
    * the translated sources and compiled classes are written to the
    * WEB-INF directory within the context root directory.
    *
    * @param source specifies the location for the JSP sources
    */  
   public Workspace(Context source) throws IOException {
      this(source, null);           
   }

   /**
    * Constructor for the <code>Workspace</code> object. This uses a
    * JSP context root to create a default configuration. With this
    * the translated sources and compiled classes are written to the
    * WEB-INF directory within the context root directory.
    *
    * @param source specifies the location for the JSP sources
    * @param name this is the name of this JSP project workspace
    */  
   public Workspace(Context source, String name) throws IOException {
      this(source, name, DEFAULT_BASE);           
   }

   /**
    * Constructor for the <code>Workspace</code> object. This uses a
    * JSP context root to create a default configuration. With this
    * constructor the sources are acquired from the provided context
    * and the build files are written, within the context, to the
    * specified directory. This is used to modify the default WEB-INF.
    * 
    * @param source this is the location JSP sources are taken from
    * @param name this is the name of this JSP project workspace
    * @param base this is the context to write the build files to
    */ 
   public Workspace(Context source, String name, String base) throws IOException {
      this(source, name, source.getFile(base));
   }

   /**
    * Constructor for the <code>Workspace</code> object. This uses a
    * JSP context root to create a default configuration. With this
    * constructor the sources are acquired from the provided context
    * and the build files are written to the directory specified.
    * This is used to store the build files out side the JSP context.
    * 
    * @param source this is the location JSP sources are taken from
    * @param name this is the name of this JSP project workspace
    * @param base this is the context to write the build files to
    */ 
   public Workspace(Context source, String name, File base) throws IOException {
      this.build = new FileContext(base);
      this.source = source;
      this.base = base;           
      this.name = name;
   } 

   /**
    * This will acquire the directory as acquired from the JSP source
    * context. This is used to determine the souce context for any
    * JSP files included recursively. For example "/some/path/File.jsp"
    * will be converted into "/some/path/" by this method.
    *
    * @param target this is the location of the JSP source file
    *
    * @return this returns the directory the source file resides in
    */ 
   public String getDirectory(String target) {
      return source.getPath(target).getDirectory();
   }

   /**
    * This acquires a file for the specified JSP source. This will
    * look in the JSP source context only. The target must be a full
    * and absolute path reference, that is, "../Path" is illegal.
    *
    * @param target this is an absolute URI path to the source
    *
    * @return this returns the OS file system reference to the file
    */ 
   public File getSourceFile(String target) {
      return source.getFile(target);           
   }

   /**
    * This acquires a file for the specified build location. This will
    * acquire the build file from the build directory used. This must
    * be an absolute path reference, that is "../Path" is illegal.
    *
    * @param target this is an absolute URI path to the build file
    *
    * @return this returns the OS file system reference to the file
    */ 
   public File getBuildFile(String target) {
      return build.getFile(target);                 
   }

   /**
    * This provides the root path for the build directory. This is 
    * used to locate the directory where the Ant compile task is to
    * be executed. All files within this directory are compiled.
    *
    * @return this returns the root file for the build directory
    */ 
   public File getBuildPath() {
      try {           
         return base.getCanonicalFile();
      }catch(Exception e) {
         return base;              
         
      }         
   }

   /**
    * This provides the name of this JSP project workspace. The name
    * provides a unique identity for the workspace, it must be a
    * valid Java package prefix as it is appended to all generated
    * pages sources. For example a workspace name of "example" would
    * translate "/demo/File.jsp" to the class "example.demo.File"
    * 
    * @return this is the name of this JSP project workspace
    */ 
   public String getName() {
      return name;               
   }
}
