/*
 * Model.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page;

import simple.template.layout.Tile;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * The <code>Model</code> is used to store all attributes that are 
 * to be passed into the page. This implements the <code>Map</code>
 * interface in such a way that it allows attribute inheritance.
 * 
 * @author Niall Gallagher
 */ 
public class Model extends HashMap {

   /**
    * This is contains the attributes from the parent map object.
    */          
   private Map root;        
        
   /**
    * Constructor for the <code>Model</code> object. This is used
    * to create an empty model, which acts much like a hash map.
    */ 
   public Model() {
      super();     
   }        

   /**
    * Constructor for the <code>Model</code> object. This is used
    * to create a model that inherits attributes from the provided
    * map instance. If the map is null then it is ignored.
    *
    * @param root this is used to provide a base set of objects
    */ 
   public Model(Map root) {
      this.root = root;      
   }

   /**
    * Acquire the attribute referenced by the provided key. This is
    * used to search for the attribute up the inheritance tree if
    * the attribute is not found in any parent map null is returned.
    *
    * @param key this is used to reference an attribute in the model
    *
    * @return this returns the attribute, or null if not found
    */ 
   public Object get(Object key) {
      if(containsKey(key)) {
         return super.get(key);              
      }          
      if(root != null) { 
         return root.get(key);
      }
      return null;      
   }

   /**
    * This method is used to write the value of the referenced value
    * directly to the <code>PrintWriter</code>. This is used when
    * the JSP references an inserted tile, but can also be used as
    * a general purpose means for displaying a model property.
    *
    * @param out this is the print writer to write the property to
    * @param key this is the name or key to the requested value
    */ 
   public void write(PrintWriter out, Object key) {
      Object value = get(key);

      if(value instanceof Tile) {
         Tile tile = (Tile) value;

         tile.write(out);         
      } else {
         out.print(value);              
      }
   }
}
