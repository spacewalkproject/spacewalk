/*
 * BasicPage.java February 2006
 *
 * Copyright (C) 2006, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.page;

import simple.http.serve.Context;

/**
 * The <code>BasicPage</code> object provides the base class for all
 * generated page objects. The translator uses this object as the
 * base if no object has been specificed in the extends JSP directive.
 * If another base class is to be used, it should extend this.
 * 
 * @author Niall Gallagher
 */ 
public abstract class BasicPage {

   /**
    * This provides a context to the underlying OS file system.
    */         
   protected Context context;   

   /**
    * This is the MIME type specified by the page implementation.
    */ 
   protected String type;

   /**
    * The path that the translated JSP source was created from.
    */ 
   protected String path;   

   /**
    * Constructor for the <code>BasicPage</code> object. This is used
    * to create an object that represents a translated JSP source.
    * This requires the file system context and the .jsp path.
    *
    * @param context this is the file system context for the page
    * @param path this is the URI path reference to the JSP source
    */   
   public BasicPage(Context context, String path) {
      this.type = context.getContentType(path);
      this.context = context;           
      this.path = path;
   }        

   /**
    * This retrieves the character encoding that should be used when
    * marshalling the character stream provided by the page to a
    * byte stream. Typically UTF-8 will satisfy most needs.
    *
    * @return this returns the page character encoding 
    */ 
   public String getCharset() {
      return "UTF-8";           
   }

   /**
    * This provides the MIME content type and character encoding of
    * for the page implementation. This can be used to set the HTTP
    * Content-Type header used for a request displaying the page.
    *
    * @return this returns the content type and charset
    */ 
   public String getContentType() {
      return type+"; "+getCharset();           
   }
}
